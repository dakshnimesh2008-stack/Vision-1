# VISION — Time. Your Way.

Native Android (Kotlin + Jetpack Compose + Material 3) clock customization app. Package: `com.daksh.vision`.

## Status: Stage 4 of 5 complete

### Done
- **Stage 1:** project setup, system/light/dark theme, brand loading screen, bottom navigation, Home, Settings
  (theme, time format, privacy, version, reset with confirmation), launcher icon.
- **Stage 2:** 25 original clock designs (Simple 8 / Animated 7 / Beautiful 10), 4 renderers, full customizer
  with live preview, persistence, battery-conscious ticking.
- **Stage 3:** real home-screen widgets (Small/Medium/Large) via `AppWidgetProvider` + `RemoteViews`, three
  widget looks, per-instance configuration, pinning via `requestPinAppWidget` with manual-instructions fallback,
  minute-accurate updates that survive reboot/time-zone/time changes.
- **Stage 4 (this stage) — Smart AOD:**
  - **Dedicated Smart AOD screen** with a mode picker (Off / Always On / Charging Only / Scheduled /
    Battery Threshold / Custom Rules), a live status card, and a "Preview VISION Ambient" action.
  - **Always On:** detects the device's native Ambient Display secure setting where exposed (`doze_always_on`,
    present on AOSP/Pixel-style builds; absent on many OEM skins — handled gracefully either way) and shows its
    current on/off state. VISION cannot flip that setting itself — no app can, without being the device's system
    UI — so it offers a legitimate shortcut into the system Display settings (`Settings.ACTION_DISPLAY_SETTINGS`)
    instead, and says so plainly rather than implying control it doesn't have.
  - **Charging Only:** reads real charging state from the device's battery broadcast (the same mechanism used by
    Stage 2/3's battery display) and reports live whether this mode is currently active.
  - **Scheduled:** real start/end time pickers (Android's native `TimePickerDialog`), a day-of-week selector, and
    an enable switch. Overnight ranges (e.g. 22:00 → 06:00) are handled correctly — covered by unit tests for
    same-day windows, overnight windows, the day-after-overnight edge case, and full-day windows.
  - **Battery Threshold:** four presets (20/30/40/50%) plus a free-form slider (1–100%), evaluated against the
    device's real battery percentage. An unreadable battery level never falsely satisfies a threshold.
  - **Custom Rules:** a real rule builder — add/remove conditions, AND/OR logic per rule, condition types
    (Charging, Battery above/below, Current time between, Schedule is enabled), each rule independently
    enabled/disabled/edited/deleted. A real evaluation engine (`AodEngine`, pure Kotlin, no Android dependency)
    computes and displays, per rule and per condition, whether it is satisfied right now. Conflict resolution
    across multiple enabled rules is explicit and documented: Custom Rules mode is active if **any** enabled
    rule is satisfied (rules combine with OR across each other; each rule's own conditions use its chosen AND/OR).
  - **"Preview VISION Ambient":** VISION's own dim, full-screen clock (reusing the Stage 2 clock library and the
    person's selected design), explicitly labelled on-screen as *"not your device's native Always-On Display."*
    It is launched only by an explicit tap — never automatically from the background, since Android does not
    allow third-party apps to pop full-screen content from the background without special permissions, and
    VISION deliberately does not request any of those (no overlay permission, no Accessibility Service, no
    device-admin, no root).
  - **Persistence:** mode, schedule, battery threshold and the full rule list are saved in DataStore and survive
    app restarts.
  - **No background service or alarm for AOD.** Status is evaluated live, from real battery and clock state,
    whenever the Smart AOD screen is open — this is a deliberate choice, not an oversight: it avoids unnecessary
    battery drain, avoids Android's background-execution restrictions entirely (there is no backgrounded action
    to restrict), and needs no new runtime permission.

### Honest limitations
- **No third-party app, VISION included, can force a true, screen-off Always-On Display.** That capability
  belongs to the device manufacturer's system UI. Smart AOD configures VISION's own behaviour and, where the
  device exposes it, links to the real system setting — it does not and cannot override it.
- Always On's capability detection depends on an undocumented-but-common secure setting key; some OEM skins
  (particularly heavily customized ones) may not expose it, in which case VISION says so and offers the system
  Display settings shortcut instead of a false reading.
- "Preview VISION Ambient" only runs while its screen is open and the app is reachable; it is not a persistent,
  background, lock-screen-level display.
- Custom Rules' conflict resolution (any satisfied rule activates the mode) is a deliberate, documented design
  choice, not the only reasonable one — it is explained above and in-app so behaviour is predictable.

### Remaining
- **Stage 5:** accessibility pass, final consolidated README/report, release notes.

## Build from a phone (GitHub Actions)
1. Create a GitHub repo and upload this folder's contents (keep the `.github` folder).
2. Actions tab → "Build VISION debug APK" → Run workflow (also runs on every push). It runs unit tests, then builds.
3. Download the `VISION-debug-apk` artifact, unzip it, install `app-debug.apk`.

No Gradle wrapper is needed; the workflow installs Gradle 8.7. Versions: AGP 8.5.2, Kotlin 1.9.24,
Compose BOM 2024.06.00, compile/target SDK 34, min SDK 26.

## Permissions
- `RECEIVE_BOOT_COMPLETED` (added in Stage 3): lets home-screen widgets resume ticking right after a restart.
  Explained in Settings → Permissions.
- No new permission was needed for Smart AOD: it reads battery/charging state (no permission required on
  modern Android), reads one secure setting if present (no permission required to read it), and opens system
  Settings via a normal, unprivileged `Intent`.
- Still no internet, accounts, ads, or analytics.

## Trying Smart AOD after installing
1. Open VISION → **Smart AOD** tab.
2. Pick a mode and configure it — the status card updates live from your device's real battery/time.
3. For Custom Rules, tap **New rule**, add one or more conditions, choose AND/OR, save.
4. Tap **Preview VISION Ambient** any time to see VISION's own on-screen clock fallback.

## Project layout
`aod/` Smart AOD models, rule engine, capability detection, live-context builder, Ambient fallback Activity ·
`clock/` clock models, library, renderers · `widgets/` `AppWidgetProvider`s, `RemoteViews`, widget config ·
`data/` DataStore repositories (settings, clocks, widgets share one store; AOD has its own repository over the
same store) · `system/` battery · `ui/` screens, theme, splash · `util/` formatting.

## Tests
Unit tests (JUnit), all pure-Kotlin:
- Stage 1–3: time formatting, clock/widget config encode-decode + corruption fallback, clock/widget library
  integrity.
- Stage 4 (new): `ScheduleTest` (same-day, overnight, midnight-crossing, full-day, disabled, encode/decode,
  corrupt-data fallback), `AodEngineTest` (every mode including null-battery edge cases, AND/OR rule logic,
  disabled-rule handling, multi-rule conflict resolution), `AodModelsCodecTest` (condition/rule encode-decode
  round trips and corrupt-data rejection, time formatting in 12h/24h including midnight and noon).
Run in CI with `gradle testDebugUnitTest`.

## Verification status (honest)
The authoring environment has no Kotlin compiler, Android SDK, or network access, so **nothing was compiled or
executed there**. What *was* done, and can be checked by anyone:
- A static checker verified balanced braces across every Kotlin file, no duplicate top-level definitions in the
  same package, every `import com.daksh.vision.*` symbol defined where it claims to be, every XML well-formed,
  every `R.id` used from Kotlin present in the layout that renders it, every `@string`/`@drawable`/`@layout`/`@xml`
  reference resolving, and every manifest-referenced class existing on disk.
- This pass caught two real bugs before packaging: an import pointing `AodRepository` at the wrong package
  (`.aod` instead of `.data`), and an invalid `Row(... horizontalAlignment = ...)` parameter that doesn't exist
  on Compose's `Row` (fixed to a correct, parameterless `Row`). A third — a dead, buggy `onChange` lambda
  left over from an earlier draft of the rule-condition editor — was found and removed by inspection.
- Because no JVM was available to actually run them, the trickiest new logic (overnight-schedule evaluation and
  null-battery threshold handling) was independently re-implemented in Python from the same specification and
  checked against the same test cases the Kotlin unit tests use. Both matched. This is a correctness cross-check,
  not a substitute for the real `gradle testDebugUnitTest` run, which still happens for the first time in CI.
- The first real compile, the first real test run, and the first real on-device check of Smart AOD (including
  whether the Ambient-Display secure setting is actually readable on your specific phone) all happen in
  GitHub Actions / on your phone. If anything looks wrong, send the error or a screenshot and it will be fixed.

package com.daksh.vision.widgets

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.daksh.vision.data.ThemeMode
import com.daksh.vision.ui.theme.VisionTheme

/**
 * Launched automatically by Android (ACTION_APPWIDGET_CONFIGURE) whenever the user drags a
 * VISION widget onto the home screen, and again when they tap "Reconfigure" from the launcher.
 * Every widget instance gets its own appWidgetId, so each one is configured independently.
 */
class WidgetConfigActivity : ComponentActivity() {
    private var appWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(Activity.RESULT_CANCELED)
        enableEdgeToEdge()

        appWidgetId = intent?.extras?.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
            ?: AppWidgetManager.INVALID_APPWIDGET_ID
        if (appWidgetId == AppWidgetManager.INVALID_APPWIDGET_ID) { finish(); return }

        val size = sizeFromProvider(this, appWidgetId)
        if (size == null) { finish(); return }

        setContent {
            VisionTheme(ThemeMode.SYSTEM) {
                Surface(Modifier.fillMaxSize()) {
                    WidgetConfigScreen(
                        size = size,
                        initial = WidgetPrefs.load(this, appWidgetId, size),
                        onConfirm = { config ->
                            WidgetPrefs.save(this, appWidgetId, config)
                            val manager = AppWidgetManager.getInstance(this)
                            manager.updateAppWidget(appWidgetId, WidgetRenderer.build(this, size, config))
                            WidgetScheduler.schedule(this, size)
                            setResult(Activity.RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId))
                            finish()
                        },
                    )
                }
            }
        }
    }

    private fun sizeFromProvider(context: android.content.Context, id: Int): WidgetSize? {
        val provider = AppWidgetManager.getInstance(context).getAppWidgetInfo(id)?.provider ?: return null
        return WidgetSize.values().firstOrNull { provider == VisionWidgetProvider.componentNameFor(context, it) }
    }
}

@Composable
fun WidgetConfigScreen(size: WidgetSize, initial: WidgetConfig, onConfirm: (WidgetConfig) -> Unit) {
    var config by remember { mutableStateOf(initial) }
    Column(
        Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text("Configure ${size.label} widget", style = MaterialTheme.typography.headlineMedium)
        WidgetPreview(size, config, Modifier.fillMaxWidth().aspectRatio(if (size == WidgetSize.SMALL) 1.3f else 2f))
        WidgetConfigForm(size, config) { config = it }
        Button(onClick = { onConfirm(config) }, modifier = Modifier.fillMaxWidth()) { Text("Add widget") }
    }
}

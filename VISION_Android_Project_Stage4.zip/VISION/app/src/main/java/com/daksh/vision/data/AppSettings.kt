package com.daksh.vision.data

enum class ThemeMode { SYSTEM, LIGHT, DARK }
enum class TimeFormat { SYSTEM, H12, H24 }

data class AppSettings(
    val theme: ThemeMode = ThemeMode.SYSTEM,
    val timeFormat: TimeFormat = TimeFormat.SYSTEM,
)

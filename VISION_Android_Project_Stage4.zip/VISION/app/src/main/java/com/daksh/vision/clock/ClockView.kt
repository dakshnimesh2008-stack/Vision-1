package com.daksh.vision.clock

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.daksh.vision.system.BatteryInfo
import com.daksh.vision.util.TimeFormatter
import java.time.LocalDateTime
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Renders any clock design from its [ClockStyle] and [ClockConfig].
 * Used by the library cards, previews, the customizer and Home so they always look identical.
 */
@Composable
fun ClockView(
    style: ClockStyle,
    config: ClockConfig,
    appUse24h: Boolean,
    battery: BatteryInfo?,
    modifier: Modifier = Modifier,
) {
    val reduced = rememberReducedMotion()
    val frames = !reduced && style.smooth &&
        (config.showSeconds || style.decor == Decor.ANIM_GRADIENT || style.decor == Decor.PULSE)
    val now = rememberNow(smooth = frames)
    val use24 = config.resolve24(appUse24h)
    val renderer = style.effectiveRenderer(config)
    val animateDigits = style.animatedDigits && !reduced

    BoxWithConstraints(modifier.clipToBounds()) {
        val w = constraints.maxWidth.toFloat()
        val h = constraints.maxHeight.toFloat()
        val bg = Color(config.background)
        val accent = Color(config.accent)
        val brush: Brush = when (style.decor) {
            Decor.GRADIENT -> Brush.linearGradient(listOf(bg, lerp(bg, accent, 0.4f)), Offset.Zero, Offset(w, h))
            Decor.GLASS -> Brush.linearGradient(
                listOf(lerp(bg, accent, 0.55f), lerp(bg, Color(config.main), 0.15f)), Offset.Zero, Offset(w, h))
            Decor.ANIM_GRADIENT -> {
                val p = (((now.second % 20) + now.nano / 1_000_000_000f) / 20f)
                Brush.linearGradient(
                    listOf(bg, lerp(bg, accent, 0.5f), bg),
                    Offset(-w + 2f * w * p, 0f), Offset(2f * w * p, h),
                )
            }
            else -> SolidColor(bg)
        }
        Box(Modifier.fillMaxSize().background(brush), contentAlignment = Alignment.Center) {
            when (renderer) {
                Renderer.DIGITAL -> DigitalFace(style, config, now, use24, battery, w, h, animateDigits)
                Renderer.ANALOG -> AnalogFace(style, config, now, battery, w, h)
                Renderer.RING -> RingFace(config, now, use24, battery, w, h)
                Renderer.ORBIT -> OrbitFace(config, now, use24, battery, w, h)
            }
        }
    }
}

// ---------------------------------------------------------------- helpers

private fun Family.toFontFamily(): FontFamily = when (this) {
    Family.SANS -> FontFamily.SansSerif
    Family.SERIF -> FontFamily.Serif
    Family.MONO -> FontFamily.Monospace
}

private fun Density.sp(px: Float) = px.toSp()

private fun frac(now: LocalDateTime) = now.nano / 1_000_000_000f

@Composable
private fun InfoLines(cfg: ClockConfig, now: LocalDateTime, battery: BatteryInfo?, sizePx: Float, family: FontFamily) {
    val d = LocalDensity.current
    val st = TextStyle(color = Color(cfg.text), fontSize = d.sp(sizePx), fontFamily = family)
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        if (cfg.showDay) Text(TimeFormatter.dayName(now).uppercase(), style = st.copy(letterSpacing = 2.sp))
        if (cfg.showDate) Text(TimeFormatter.dateShort(now), style = st)
        if (cfg.showBattery && battery != null) Text(battery.label, style = st)
    }
}

/** Time text; when [animated], each digit slides vertically when it changes. */
@Composable
private fun TimeText(text: String, style: TextStyle, animated: Boolean) {
    if (!animated) {
        Text(text, style = style, maxLines = 1)
        return
    }
    Row {
        text.forEachIndexed { index, ch ->
            key(index) {
                if (ch.isDigit()) {
                    AnimatedContent(
                        targetState = ch,
                        transitionSpec = {
                            (slideInVertically(tween(300)) { it / 2 } + fadeIn(tween(300))) togetherWith
                                (slideOutVertically(tween(300)) { -it / 2 } + fadeOut(tween(200)))
                        },
                        label = "digit",
                    ) { c -> Text(c.toString(), style = style, maxLines = 1) }
                } else {
                    Text(ch.toString(), style = style, maxLines = 1)
                }
            }
        }
    }
}

// ---------------------------------------------------------------- digital

@Composable
private fun DigitalFace(
    style: ClockStyle, cfg: ClockConfig, now: LocalDateTime, use24: Boolean,
    battery: BatteryInfo?, w: Float, h: Float, animateDigits: Boolean,
) {
    val d = LocalDensity.current
    var timePx = if (style.stacked) min(w * 0.32f, h * 0.30f) else min(w * 0.2f, h * 0.36f)
    timePx *= style.sizeScale
    if (cfg.showSeconds && !style.stacked) timePx *= 0.82f
    val smallPx = timePx * 0.26f
    val family = cfg.font.family.toFontFamily()
    val weight = FontWeight(cfg.font.weight ?: style.weight)
    val glow = if (style.decor == Decor.GLOW)
        Shadow(Color(cfg.accent), Offset.Zero, timePx * 0.3f) else null
    val timeStyle = TextStyle(
        color = Color(cfg.main), fontSize = d.sp(timePx), fontFamily = family, fontWeight = weight,
        fontFeatureSettings = "tnum", shadow = glow,
    )
    val accentSmall = TextStyle(color = Color(cfg.accent), fontSize = d.sp(smallPx * 1.2f), fontFamily = family)

    val content: @Composable () -> Unit = {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            if (style.decor == Decor.PULSE) {
                val t = 1f - frac(now)
                Box(
                    Modifier.size(with(d) { (smallPx * 0.6f).toDp() })
                        .graphicsLayer { scaleX = 0.6f + 0.4f * t; scaleY = 0.6f + 0.4f * t; alpha = 0.4f + 0.6f * t }
                        .background(Color(cfg.accent), CircleShape),
                )
            }
            if (style.stacked) {
                val hh = TimeFormatter.time(now, use24, false).substringBefore(':')
                val mm = TimeFormatter.time(now, use24, false).substringAfter(':')
                TimeText(hh, timeStyle, animateDigits)
                TimeText(mm, timeStyle, animateDigits)
                if (cfg.showSeconds) Text(":" + "%02d".format(now.second), style = accentSmall)
            } else {
                Row(verticalAlignment = Alignment.Bottom) {
                    TimeText(TimeFormatter.time(now, use24, cfg.showSeconds), timeStyle, animateDigits)
                    val ap = TimeFormatter.amPm(now, use24)
                    if (ap.isNotEmpty()) Text(ap, style = accentSmall, modifier = Modifier.padding(start = 6.dp, bottom = 4.dp))
                }
            }
            if (style.stacked) {
                val ap = TimeFormatter.amPm(now, use24)
                if (ap.isNotEmpty()) Text(ap, style = accentSmall)
            }
            InfoLines(cfg, now, battery, smallPx, family)
        }
    }

    if (style.decor == Decor.GLASS) {
        Box(
            Modifier.padding(with(d) { (min(w, h) * 0.1f).toDp() })
                .background(Color.White.copy(alpha = 0.12f), RoundedCornerShape(24.dp))
                .border(1.dp, Color.White.copy(alpha = 0.28f), RoundedCornerShape(24.dp))
                .padding(horizontal = 24.dp, vertical = 12.dp),
            contentAlignment = Alignment.Center,
        ) { content() }
    } else {
        content()
    }
}

// ---------------------------------------------------------------- analog

private fun DrawScope.pt(c: Offset, angleDeg: Float, len: Float): Offset {
    val rad = Math.toRadians(angleDeg.toDouble())
    return Offset(c.x + len * sin(rad).toFloat(), c.y - len * cos(rad).toFloat())
}

@Composable
private fun AnalogFace(
    style: ClockStyle, cfg: ClockConfig, now: LocalDateTime, battery: BatteryInfo?, w: Float, h: Float,
) {
    val d = LocalDensity.current
    val dial = min(w, h) * 0.9f
    val main = Color(cfg.main); val accent = Color(cfg.accent); val text = Color(cfg.text)
    val variant = style.analogVariant
    val sec = now.second + frac(now)
    val minute = now.minute + sec / 60f
    val hour = (now.hour % 12) + minute / 60f
    val numeralSize = dial * if (variant == AnalogVariant.NUMERALS) 0.12f else 0.075f
    val paint = remember(cfg.text, numeralSize, variant) {
        Paint().apply {
            isAntiAlias = true
            color = text.toArgb()
            textSize = numeralSize
            textAlign = Paint.Align.CENTER
            typeface = if (variant == AnalogVariant.NUMERALS) Typeface.DEFAULT_BOLD else Typeface.SERIF
        }
    }
    val hasInfo = cfg.showDay || cfg.showDate || (cfg.showBattery && battery != null)
    Box(Modifier.size(with(d) { dial.toDp() }), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val c = center
            val r = size.minDimension / 2f
            val elegant = variant == AnalogVariant.ELEGANT
            if (elegant) drawCircle(accent.copy(alpha = 0.6f), r * 0.98f, c, style = Stroke(r * 0.012f))

            // ticks
            for (i in 0 until 60) {
                val major = i % 5 == 0
                val a = i * 6f
                when (variant) {
                    AnalogVariant.CLASSIC ->
                        drawLine(text.copy(alpha = if (major) 0.9f else 0.45f),
                            pt(c, a, r * (if (major) 0.84f else 0.9f)), pt(c, a, r * 0.96f),
                            strokeWidth = r * (if (major) 0.025f else 0.01f), cap = StrokeCap.Round)
                    AnalogVariant.ELEGANT -> if (major)
                        drawLine(text.copy(alpha = 0.8f), pt(c, a, r * 0.86f), pt(c, a, r * 0.94f),
                            strokeWidth = r * 0.012f, cap = StrokeCap.Round)
                    AnalogVariant.MINIMAL -> if (i % 15 == 0)
                        drawCircle(text, r * 0.022f, pt(c, a, r * 0.92f))
                    AnalogVariant.NUMERALS -> Unit
                }
            }
            // numerals
            if (variant == AnalogVariant.CLASSIC || variant == AnalogVariant.NUMERALS) {
                val fm = paint.fontMetrics
                val pos = if (variant == AnalogVariant.CLASSIC) 0.7f else 0.78f
                for (n in 1..12) {
                    val p = pt(c, n * 30f, r * pos)
                    drawContext.canvas.nativeCanvas.drawText(n.toString(), p.x, p.y - (fm.ascent + fm.descent) / 2f, paint)
                }
            }
            // hands
            val hourW = r * (if (elegant) 0.03f else 0.055f)
            val minW = r * (if (elegant) 0.02f else 0.035f)
            val hourLen = r * (if (variant == AnalogVariant.NUMERALS) 0.42f else 0.5f)
            drawLine(main, c, pt(c, hour * 30f, hourLen), strokeWidth = hourW, cap = StrokeCap.Round)
            drawLine(main, c, pt(c, minute * 6f, r * (if (variant == AnalogVariant.NUMERALS) 0.62f else 0.75f)),
                strokeWidth = minW, cap = StrokeCap.Round)
            if (cfg.showSeconds) {
                drawLine(accent, pt(c, sec * 6f + 180f, r * 0.15f), pt(c, sec * 6f, r * 0.85f),
                    strokeWidth = r * 0.014f, cap = StrokeCap.Round)
            }
            drawCircle(accent, r * 0.045f, c)
        }
        if (hasInfo) {
            Box(Modifier.offset(y = with(d) { (dial * 0.27f).toDp() })) {
                InfoLines(cfg, now, battery, dial * 0.05f, FontFamily.SansSerif)
            }
        }
    }
}

// ---------------------------------------------------------------- ring (progress) and orbit

@Composable
private fun CenterText(cfg: ClockConfig, now: LocalDateTime, use24: Boolean, battery: BatteryInfo?, timePx: Float) {
    val d = LocalDensity.current
    val family = cfg.font.family.toFontFamily()
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            TimeFormatter.time(now, use24, false),
            style = TextStyle(color = Color(cfg.main), fontSize = d.sp(timePx), fontFamily = family,
                fontWeight = FontWeight(cfg.font.weight ?: 300), fontFeatureSettings = "tnum"),
            maxLines = 1,
        )
        InfoLines(cfg, now, battery, timePx * 0.32f, family)
    }
}

@Composable
private fun RingFace(cfg: ClockConfig, now: LocalDateTime, use24: Boolean, battery: BatteryInfo?, w: Float, h: Float) {
    val d = LocalDensity.current
    val dial = min(w, h) * 0.9f
    val sec = now.second + frac(now)
    val minute = now.minute + sec / 60f
    val hour = (now.hour % 12) + minute / 60f
    val track = Color(cfg.text).copy(alpha = 0.14f)
    Box(Modifier.size(with(d) { dial.toDp() }), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val r = size.minDimension / 2f
            val sw = r * 0.07f
            fun ring(radius: Float, fraction: Float, color: Color) {
                val tl = Offset(center.x - radius, center.y - radius)
                val sz = Size(radius * 2, radius * 2)
                drawArc(track, 0f, 360f, false, tl, sz, style = Stroke(sw))
                drawArc(color, -90f, 360f * fraction, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
            }
            var radius = r - sw
            if (cfg.showSeconds) { ring(radius, sec / 60f, Color(cfg.text)); radius -= sw * 1.7f }
            ring(radius, minute / 60f, Color(cfg.accent)); radius -= sw * 1.7f
            ring(radius, hour / 12f, Color(cfg.main))
        }
        CenterText(cfg, now, use24, battery, dial * 0.17f)
    }
}

@Composable
private fun OrbitFace(cfg: ClockConfig, now: LocalDateTime, use24: Boolean, battery: BatteryInfo?, w: Float, h: Float) {
    val d = LocalDensity.current
    val dial = min(w, h) * 0.9f
    val sec = now.second + frac(now)
    val minute = now.minute + sec / 60f
    val hour = (now.hour % 12) + minute / 60f
    val orbit = Color(cfg.text).copy(alpha = 0.18f)
    Box(Modifier.size(with(d) { dial.toDp() }), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val c = center
            val r = size.minDimension / 2f
            val sw = r * 0.008f
            drawCircle(orbit, r * 0.5f, c, style = Stroke(sw))
            drawCircle(orbit, r * 0.72f, c, style = Stroke(sw))
            drawCircle(orbit, r * 0.94f, c, style = Stroke(sw))
            drawCircle(Color(cfg.main), r * 0.07f, pt(c, hour * 30f, r * 0.5f))
            drawCircle(Color(cfg.accent), r * 0.055f, pt(c, minute * 6f, r * 0.72f))
            if (cfg.showSeconds) drawCircle(Color(cfg.text), r * 0.04f, pt(c, sec * 6f, r * 0.94f))
        }
        CenterText(cfg, now, use24, battery, dial * 0.12f)
    }
}

package com.daksh.vision.aod

import androidx.compose.runtime.Composable
import com.daksh.vision.clock.rememberNow
import com.daksh.vision.system.BatteryInfo
import java.time.LocalDateTime

private val weekdayOrder = listOf(
    Weekday.SUN, Weekday.MON, Weekday.TUE, Weekday.WED, Weekday.THU, Weekday.FRI, Weekday.SAT,
)

/** java.time.DayOfWeek is Monday-first (1=Mon..7=Sun); VISION's Weekday is Sunday-first to match a typical day-picker row. */
private fun LocalDateTime.toWeekday(): Weekday = weekdayOrder[dayOfWeek.value % 7]

fun buildContext(now: LocalDateTime, battery: BatteryInfo?): AodContext {
    val today = now.toWeekday()
    val yesterday = weekdayOrder[(weekdayOrder.indexOf(today) + 6) % 7]
    return AodContext(
        charging = battery?.charging ?: false,
        batteryPercent = battery?.percent,
        minutesOfDay = now.hour * 60 + now.minute,
        weekday = today,
        previousWeekday = yesterday,
    )
}

/** Recomputed every second the Smart AOD screen is visible, from real battery + clock state. */
@Composable
fun rememberAodContext(battery: BatteryInfo?): AodContext {
    val now = rememberNow()
    return buildContext(now, battery)
}

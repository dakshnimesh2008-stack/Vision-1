package com.daksh.vision.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.daksh.vision.clock.ClockConfig
import com.daksh.vision.clock.ClockFont
import com.daksh.vision.clock.ClockState
import com.daksh.vision.clock.ClockStyle
import com.daksh.vision.clock.ClockView
import com.daksh.vision.clock.FormatChoice
import com.daksh.vision.clock.ClockLibrary
import com.daksh.vision.clock.Option
import com.daksh.vision.clock.Palette
import com.daksh.vision.data.AppSettings
import com.daksh.vision.system.rememberBattery

@Composable
fun CustomizeScreen(
    styleId: String,
    settings: AppSettings,
    clocks: ClockState,
    onBack: () -> Unit,
    onSave: (String, ClockConfig) -> Unit,
    onApply: (String, ClockConfig) -> Unit,
) {
    val style = ClockLibrary.byId(styleId)
    if (style == null) {
        Column(Modifier.fillMaxSize().statusBarsPadding().padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Clock not found", style = MaterialTheme.typography.headlineMedium)
            Text("This clock design is no longer available.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Button(onClick = onBack) { Text("Back to Clocks") }
        }
    } else {
        CustomizeContent(style, settings, clocks, onBack, onSave, onApply)
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun CustomizeContent(
    style: ClockStyle,
    settings: AppSettings,
    clocks: ClockState,
    onBack: () -> Unit,
    onSave: (String, ClockConfig) -> Unit,
    onApply: (String, ClockConfig) -> Unit,
) {
    val saved = clocks.configFor(style)
    // Draft is kept as its encoded string so it survives rotation without extra Parcelable code.
    var draftRaw by rememberSaveable(style.id) { mutableStateOf(saved.encode()) }
    val draft = remember(draftRaw) { ClockConfig.decode(draftRaw, style.defaults) }
    fun update(c: ClockConfig) { draftRaw = c.encode() }

    val options = style.options(draft)
    val battery = rememberBattery()
    val use24 = resolveUse24h(settings)
    val dirty = draftRaw != saved.encode()
    val applied = clocks.selectedId == style.id

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back") }
            Column {
                Text(style.name, style = MaterialTheme.typography.titleMedium)
                Text(
                    style.category.label + if (applied) " · Applied" else "",
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 24.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            ClockView(style, draft, use24, battery, Modifier.fillMaxWidth().aspectRatio(1.6f).clip(RoundedCornerShape(24.dp)))
            Text(
                if (dirty) "Unsaved changes" else "All changes saved",
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            if (Option.PRESENTATION in options) {
                Label("Presentation")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(!draft.analog, { update(draft.copy(analog = false)) }, { Text("Digital") })
                    FilterChip(draft.analog, { update(draft.copy(analog = true)) }, { Text("Analog") })
                }
            }
            if (Option.MAIN in options) ColorRow("Main colour", Palette.foreground, draft.main) { update(draft.copy(main = it)) }
            if (Option.ACCENT in options) ColorRow("Accent colour", Palette.foreground, draft.accent) { update(draft.copy(accent = it)) }
            if (Option.BACKGROUND in options) ColorRow("Background colour", Palette.backgrounds, draft.background) { update(draft.copy(background = it)) }
            if (Option.TEXT in options) ColorRow("Text colour", Palette.textColors, draft.text) { update(draft.copy(text = it)) }
            if (Option.FONT in options) {
                Label("Font style")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ClockFont.values().forEach { f -> FilterChip(draft.font == f, { update(draft.copy(font = f)) }, { Text(f.label) }) }
                }
            }
            if (Option.FORMAT in options) {
                Label("Time format")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FormatChoice.values().forEach { f -> FilterChip(draft.format == f, { update(draft.copy(format = f)) }, { Text(f.label) }) }
                }
            }
            if (Option.DATE in options) SwitchRow("Show date", draft.showDate) { update(draft.copy(showDate = it)) }
            if (Option.DAY in options) SwitchRow("Show day", draft.showDay) { update(draft.copy(showDay = it)) }
            if (Option.SECONDS in options) SwitchRow("Show seconds", draft.showSeconds) { update(draft.copy(showSeconds = it)) }
            if (Option.BATTERY in options) {
                SwitchRow(
                    if (battery == null) "Show battery (unavailable on this device)" else "Show battery",
                    draft.showBattery, enabled = battery != null,
                ) { update(draft.copy(showBattery = it)) }
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically,
        ) {
            OutlinedButton(onClick = { update(style.defaults) }, enabled = draftRaw != style.defaults.encode()) { Text("Reset") }
            OutlinedButton(onClick = { onSave(style.id, draft) }, enabled = dirty) { Text("Save") }
            Button(onClick = { onApply(style.id, draft) }, enabled = dirty || !applied, modifier = Modifier.weight(1f)) {
                Text(if (applied && !dirty) "Applied" else "Apply")
            }
        }
    }
}

@Composable
private fun Label(text: String) =
    Text(text, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)

@Composable
private fun SwitchRow(label: String, checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        Switch(checked = checked && enabled, onCheckedChange = onChange, enabled = enabled)
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ColorRow(label: String, palette: List<Palette.Swatch>, selected: Int, onPick: (Int) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Label(label)
        FlowRow {
            palette.forEach { sw ->
                val isSel = sw.argb == selected
                // 48dp touch target around a 34dp swatch.
                Box(
                    Modifier.size(48.dp).clip(CircleShape).clickable { onPick(sw.argb) }
                        .semantics { contentDescription = "$label ${sw.name}" + if (isSel) ", selected" else "" },
                    contentAlignment = Alignment.Center,
                ) {
                    Box(
                        Modifier.size(34.dp).clip(CircleShape).background(Color(sw.argb))
                            .border(
                                if (isSel) 3.dp else 1.dp,
                                if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                                CircleShape,
                            ),
                    )
                }
            }
        }
    }
}

package com.daksh.vision.widgets

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.daksh.vision.clock.FormatChoice
import com.daksh.vision.clock.Palette

/** The controls shared by the in-app Widgets screen's quick-pick and the system configure Activity. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun WidgetConfigForm(size: WidgetSize, config: WidgetConfig, onChange: (WidgetConfig) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Section("Look")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            WidgetLook.values().forEach { l ->
                FilterChip(config.look == l, { onChange(config.copy(look = l)) }, { Text(l.label) })
            }
        }
        Section("Main colour")
        Swatches(Palette.foreground, config.main) { onChange(config.copy(main = it)) }
        Section("Accent colour")
        Swatches(Palette.foreground, config.accent) { onChange(config.copy(accent = it)) }
        Section("Background colour")
        Swatches(Palette.backgrounds, config.background) { onChange(config.copy(background = it)) }
        Section("Time format")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FormatChoice.values().forEach { f ->
                FilterChip(config.format == f, { onChange(config.copy(format = f)) }, { Text(f.label) })
            }
        }
        if (size != WidgetSize.SMALL) SwitchRow("Show date", config.showDate) { onChange(config.copy(showDate = it)) }
        if (size == WidgetSize.LARGE) SwitchRow("Show day", config.showDay) { onChange(config.copy(showDay = it)) }
        if (size == WidgetSize.LARGE) SwitchRow("Show battery", config.showBattery) { onChange(config.copy(showBattery = it)) }
    }
}

@Composable
private fun Section(text: String) =
    Text(text, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun Swatches(palette: List<Palette.Swatch>, selected: Int, onPick: (Int) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        palette.forEach { sw ->
            val isSel = sw.argb == selected
            Box(
                Modifier.size(44.dp).clip(CircleShape).clickable { onPick(sw.argb) }
                    .semantics { contentDescription = sw.name + if (isSel) ", selected" else "" },
                contentAlignment = Alignment.Center,
            ) {
                Box(
                    Modifier.size(30.dp).clip(CircleShape).background(Color(sw.argb))
                        .border(
                            if (isSel) 3.dp else 1.dp,
                            if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                            CircleShape,
                        ),
                )
            }
        }
    }
}

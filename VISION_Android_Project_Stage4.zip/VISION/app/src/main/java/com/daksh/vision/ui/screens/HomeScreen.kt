package com.daksh.vision.ui.screens

import android.text.format.DateFormat
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.daksh.vision.clock.ClockState
import com.daksh.vision.clock.ClockView
import com.daksh.vision.clock.rememberNow
import com.daksh.vision.data.AppSettings
import com.daksh.vision.data.TimeFormat
import com.daksh.vision.system.rememberBattery
import com.daksh.vision.ui.Dest
import com.daksh.vision.util.TimeFormatter

@Composable
fun resolveUse24h(settings: AppSettings): Boolean = when (settings.timeFormat) {
    TimeFormat.H24 -> true
    TimeFormat.H12 -> false
    TimeFormat.SYSTEM -> DateFormat.is24HourFormat(LocalContext.current)
}

@Composable
fun HomeScreen(
    settings: AppSettings,
    clocks: ClockState,
    onNavigate: (Dest) -> Unit,
    onCustomize: (String) -> Unit,
) {
    val now = rememberNow()
    val use24h = resolveUse24h(settings)
    val battery = rememberBattery()
    val style = clocks.selected
    Column(
        Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text("VISION", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
        Column(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
            Row {
                Text(TimeFormatter.time(now, use24h, showSeconds = false), style = MaterialTheme.typography.displayLarge)
                val ampm = TimeFormatter.amPm(now, use24h)
                if (ampm.isNotEmpty()) {
                    Text(ampm, style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(start = 8.dp, top = 28.dp))
                }
            }
            Text(TimeFormatter.date(now), style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ClockView(
                    style, clocks.configFor(style), use24h, battery,
                    Modifier.fillMaxWidth().aspectRatio(1.6f).clip(RoundedCornerShape(16.dp)),
                )
                Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Your clock · ${style.name}", style = MaterialTheme.typography.titleMedium)
                        Text(style.category.label, style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    TextButton(onClick = { onCustomize(style.id) }) { Text("Customize") }
                }
            }
        }
        ShortcutCard("Clocks", "Browse 25 designs: Simple, Animated, Beautiful", Dest.Clocks, onNavigate)
        ShortcutCard("Widgets", "Add a clock to your home screen (coming in Stage 3)", Dest.Widgets, onNavigate)
        ShortcutCard("Smart AOD", "Rules for when your clock display is active (coming in Stage 4)", Dest.Aod, onNavigate)
    }
}

@Composable
private fun ShortcutCard(title: String, subtitle: String, dest: Dest, onNavigate: (Dest) -> Unit) {
    Card(
        Modifier.fillMaxWidth().clickable { onNavigate(dest) },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    ) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

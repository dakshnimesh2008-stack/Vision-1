package com.daksh.vision.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.daksh.vision.MainViewModel
import com.daksh.vision.R
import com.daksh.vision.data.AppSettings
import com.daksh.vision.data.ThemeMode
import com.daksh.vision.data.TimeFormat

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(settings: AppSettings, vm: MainViewModel) {
    var confirmReset by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val version = remember {
        runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull() ?: "unknown"
    }
    Column(
        Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Settings", style = MaterialTheme.typography.headlineMedium)

        Section("Theme")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(ThemeMode.SYSTEM to "System", ThemeMode.LIGHT to "Light", ThemeMode.DARK to "Dark").forEach { (m, label) ->
                FilterChip(selected = settings.theme == m, onClick = { vm.setTheme(m) }, label = { Text(label) })
            }
        }

        Section("Time format")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(TimeFormat.SYSTEM to "System", TimeFormat.H12 to "12-hour", TimeFormat.H24 to "24-hour").forEach { (f, label) ->
                FilterChip(selected = settings.timeFormat == f, onClick = { vm.setTimeFormat(f) }, label = { Text(label) })
            }
        }

        Section("Privacy")
        Text(
            "VISION works fully offline. It has no internet permission, no accounts, no ads and no analytics. " +
                "All settings stay on this device.",
            style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Section("Permissions")
        Text(
            stringResource(R.string.permission_boot_explanation),
            style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Section("About")
        Text("VISION $version · Time. Your Way.", style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant)

        OutlinedButton(onClick = { confirmReset = true }) { Text("Reset preferences") }
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Reset preferences?") },
            text = { Text("Theme and time format return to their defaults.") },
            confirmButton = { TextButton(onClick = { vm.resetAll(); confirmReset = false }) { Text("Reset") } },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun Section(title: String) {
    Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 12.dp))
}

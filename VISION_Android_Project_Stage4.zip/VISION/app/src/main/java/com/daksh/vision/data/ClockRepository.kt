package com.daksh.vision.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import com.daksh.vision.clock.ClockConfig
import com.daksh.vision.clock.ClockLibrary
import com.daksh.vision.clock.ClockState
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/** Persists the selected clock and one saved configuration per clock design. */
class ClockRepository(private val context: Context) {
    private val selectedKey = stringPreferencesKey("selected_clock")
    private fun cfgKey(id: String) = stringPreferencesKey("cfg_$id")

    val state: Flow<ClockState> = context.visionStore.data.map { prefs ->
        val selected = ClockLibrary.byId(prefs[selectedKey])?.id ?: ClockLibrary.DEFAULT_ID
        val configs = ClockLibrary.all.associate { s ->
            s.id to ClockConfig.decode(prefs[cfgKey(s.id)], s.defaults)
        }
        ClockState(selected, configs)
    }

    suspend fun select(id: String) {
        if (ClockLibrary.byId(id) == null) return
        context.visionStore.edit { it[selectedKey] = id }
    }

    suspend fun save(id: String, config: ClockConfig) {
        if (ClockLibrary.byId(id) == null) return
        context.visionStore.edit { it[cfgKey(id)] = config.encode() }
    }

    /** Save the configuration and make this clock the selected one, in a single atomic write. */
    suspend fun apply(id: String, config: ClockConfig) {
        if (ClockLibrary.byId(id) == null) return
        context.visionStore.edit {
            it[cfgKey(id)] = config.encode()
            it[selectedKey] = id
        }
    }
}

package com.daksh.vision.widgets

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.SystemClock

/**
 * Schedules a once-per-minute, inexact repeating alarm per widget size so the clock stays
 * accurate without a foreground service or per-second wakeups. Inexact alarms need no special
 * "exact alarm" permission. Alarms don't survive reboot, so [WidgetSystemReceiver] reschedules
 * them on BOOT_COMPLETED.
 */
object WidgetScheduler {
    private const val ONE_MINUTE_MILLIS = 60_000L
    private fun action(size: WidgetSize) = "com.daksh.vision.WIDGET_TICK_${size.name}"

    private fun pendingIntent(context: Context, size: WidgetSize): PendingIntent {
        val providerClass = when (size) {
            WidgetSize.SMALL -> SmallClockWidget::class.java
            WidgetSize.MEDIUM -> MediumClockWidget::class.java
            WidgetSize.LARGE -> LargeClockWidget::class.java
        }
        val intent = Intent(context, providerClass).setAction(action(size))
        return PendingIntent.getBroadcast(context, size.ordinal, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    fun schedule(context: Context, size: WidgetSize) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val next = SystemClock.elapsedRealtime().let { it - (it % 60_000L) + 60_000L }
        am.setRepeating(AlarmManager.ELAPSED_REALTIME, next, ONE_MINUTE_MILLIS, pendingIntent(context, size))
    }

    fun cancel(context: Context, size: WidgetSize) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        am.cancel(pendingIntent(context, size))
    }

    fun matchesTick(intent: Intent, size: WidgetSize): Boolean = intent.action == action(size)
}

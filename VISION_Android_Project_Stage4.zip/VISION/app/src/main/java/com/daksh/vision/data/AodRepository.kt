package com.daksh.vision.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import com.daksh.vision.aod.AodMode
import com.daksh.vision.aod.AodState
import com.daksh.vision.aod.CustomRule
import com.daksh.vision.aod.Schedule
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.UUID

/** Persists Smart AOD configuration: mode, schedule, battery threshold and custom rules. */
class AodRepository(private val context: Context) {
    private val modeKey = stringPreferencesKey("aod_mode")
    private val scheduleKey = stringPreferencesKey("aod_schedule")
    private val thresholdKey = intPreferencesKey("aod_threshold")
    private val rulesKey = stringPreferencesKey("aod_rules")

    val state: Flow<AodState> = context.visionStore.data.map { prefs ->
        AodState(
            mode = AodMode.values().firstOrNull { it.name == prefs[modeKey] } ?: AodMode.OFF,
            schedule = Schedule.decode(prefs[scheduleKey], Schedule()),
            batteryThreshold = prefs[thresholdKey]?.coerceIn(1, 100) ?: 30,
            rules = prefs[rulesKey]?.split("\u0001")?.mapNotNull { if (it.isBlank()) null else CustomRule.decode(it) } ?: emptyList(),
        )
    }

    suspend fun setMode(mode: AodMode) = context.visionStore.edit { it[modeKey] = mode.name }
    suspend fun setSchedule(schedule: Schedule) = context.visionStore.edit { it[scheduleKey] = schedule.encode() }
    suspend fun setBatteryThreshold(percent: Int) = context.visionStore.edit { it[thresholdKey] = percent.coerceIn(1, 100) }

    private suspend fun saveRules(rules: List<CustomRule>) =
        context.visionStore.edit { it[rulesKey] = rules.joinToString("\u0001") { r -> r.encode() } }

    suspend fun addRule(rule: CustomRule, current: List<CustomRule>) = saveRules(current + rule)
    suspend fun updateRule(rule: CustomRule, current: List<CustomRule>) = saveRules(current.map { if (it.id == rule.id) rule else it })
    suspend fun deleteRule(id: String, current: List<CustomRule>) = saveRules(current.filterNot { it.id == id })
    suspend fun setRuleEnabled(id: String, enabled: Boolean, current: List<CustomRule>) =
        saveRules(current.map { if (it.id == id) it.copy(enabled = enabled) else it })

    companion object {
        fun newRuleId(): String = UUID.randomUUID().toString()
    }
}

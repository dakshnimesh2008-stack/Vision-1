package com.daksh.vision.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.daksh.vision.clock.ClockCategory
import com.daksh.vision.clock.ClockLibrary
import com.daksh.vision.clock.ClockState
import com.daksh.vision.clock.ClockStyle
import com.daksh.vision.clock.ClockView
import com.daksh.vision.data.AppSettings
import com.daksh.vision.system.BatteryInfo
import com.daksh.vision.system.rememberBattery

@Composable
fun ClocksScreen(
    settings: AppSettings,
    clocks: ClockState,
    onCustomize: (String) -> Unit,
    onApply: (String) -> Unit,
) {
    var category by rememberSaveable { mutableStateOf(ClockCategory.SIMPLE.name) }
    var previewId by rememberSaveable { mutableStateOf<String?>(null) }
    val current = ClockCategory.values().firstOrNull { it.name == category } ?: ClockCategory.SIMPLE
    val use24 = resolveUse24h(settings)
    val battery = rememberBattery()

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Text("Clocks", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.padding(start = 24.dp, top = 24.dp, end = 24.dp))
        Row(Modifier.padding(horizontal = 24.dp, vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ClockCategory.values().forEach { c ->
                FilterChip(selected = c == current, onClick = { category = c.name }, label = { Text(c.label) })
            }
        }
        LazyColumn(
            contentPadding = PaddingValues(start = 24.dp, end = 24.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            items(ClockLibrary.byCategory(current), key = { it.id }) { style ->
                ClockCard(
                    style = style, clocks = clocks, use24 = use24, battery = battery,
                    onPreview = { previewId = style.id },
                    onCustomize = { onCustomize(style.id) },
                    onApply = { onApply(style.id) },
                )
            }
        }
    }

    ClockLibrary.byId(previewId)?.let { style ->
        PreviewDialog(style, clocks, use24, battery, onClose = { previewId = null }, onApply = { onApply(style.id); previewId = null })
    }
}

@Composable
private fun ClockCard(
    style: ClockStyle, clocks: ClockState, use24: Boolean, battery: BatteryInfo?,
    onPreview: () -> Unit, onCustomize: () -> Unit, onApply: () -> Unit,
) {
    val applied = clocks.selectedId == style.id
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            ClockView(
                style, clocks.configFor(style), use24, battery,
                Modifier.fillMaxWidth().aspectRatio(1.6f).clip(RoundedCornerShape(16.dp)),
            )
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(style.name, style = MaterialTheme.typography.titleMedium)
                    Text(
                        if (applied) "${style.category.label} · Applied" else style.category.label,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onPreview) { Text("Preview") }
                TextButton(onClick = onCustomize) { Text("Customize") }
                Box(Modifier.weight(1f), contentAlignment = Alignment.CenterEnd) {
                    if (applied) FilledTonalButton(onClick = {}, enabled = false) { Text("Applied") }
                    else Button(onClick = onApply) { Text("Apply") }
                }
            }
        }
    }
}

@Composable
private fun PreviewDialog(
    style: ClockStyle, clocks: ClockState, use24: Boolean, battery: BatteryInfo?,
    onClose: () -> Unit, onApply: () -> Unit,
) {
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize()) {
            ClockView(style, clocks.configFor(style), use24, battery, Modifier.fillMaxSize())
            IconButton(onClick = onClose, modifier = Modifier.align(Alignment.TopEnd).padding(16.dp).background(Color.Black.copy(alpha = 0.4f), CircleShape)) {
                Icon(Icons.Outlined.Close, contentDescription = "Close preview", tint = Color.White)
            }
            if (clocks.selectedId != style.id) {
                Button(onClick = onApply, modifier = Modifier.align(Alignment.BottomCenter).padding(32.dp)) {
                    Text("Apply this clock")
                }
            }
        }
    }
}

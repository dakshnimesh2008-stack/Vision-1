package com.daksh.vision.ui.screens

import android.content.Intent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.daksh.vision.MainViewModel
import com.daksh.vision.aod.AodEngine
import com.daksh.vision.aod.AodMode
import com.daksh.vision.aod.AodState
import com.daksh.vision.aod.AmbientActivity
import com.daksh.vision.aod.rememberAodContext
import com.daksh.vision.data.AppSettings
import com.daksh.vision.system.rememberBattery

@Composable
fun AodScreen(settings: AppSettings, aod: AodState, vm: MainViewModel) {
    val battery = rememberBattery()
    val ctx = rememberAodContext(battery)
    val active = AodEngine.isActive(aod, ctx)
    val context = LocalContext.current

    LazyColumn(
        Modifier.statusBarsPadding(),
        contentPadding = PaddingValues(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item {
            Text("Smart AOD", style = MaterialTheme.typography.headlineMedium)
            Text(
                "Configure when your clock display is active, and preview VISION's own ambient screen.",
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 4.dp, bottom = 4.dp),
            )
        }
        item { StatusCard(aod.mode, active, battery) }
        item { ModePicker(aod.mode) { vm.setAodMode(it) } }
        item {
            when (aod.mode) {
                AodMode.OFF -> InfoNote("Smart AOD is off. Pick a mode above to configure it.")
                AodMode.ALWAYS_ON -> AlwaysOnCard(context)
                AodMode.CHARGING_ONLY -> ChargingOnlyCard(battery)
                AodMode.SCHEDULED -> ScheduledCard(aod, settings, vm)
                AodMode.BATTERY_THRESHOLD -> BatteryThresholdCard(aod, battery, vm)
                AodMode.CUSTOM_RULES -> {} // rendered as its own lazy items below
            }
        }
        if (aod.mode == AodMode.CUSTOM_RULES) {
            item { CustomRulesHeader(vm) }
            items(aod.rules, key = { it.id }) { rule ->
                RuleCard(rule, ctx, settings, vm)
            }
            if (aod.rules.isEmpty()) item { InfoNote("No rules yet. Tap \"New rule\" above to build one.") }
        }
        item {
            AmbientPreviewButton(context)
        }
        item { AodLimitationsNote() }
    }
}

@Composable
private fun StatusCard(mode: AodMode, active: Boolean, battery: com.daksh.vision.system.BatteryInfo?) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                if (mode == AodMode.OFF) "Status: off" else if (active) "Status: active now" else "Status: not active right now",
                style = MaterialTheme.typography.titleMedium,
                color = if (active && mode != AodMode.OFF) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
            )
            Text(
                if (battery != null) "Battery ${battery.percent}%${if (battery.charging) " · Charging" else ""}" else "Battery status unavailable on this device",
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun InfoNote(text: String) =
    Text(text, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)

@Composable
private fun AmbientPreviewButton(context: android.content.Context) {
    androidx.compose.material3.OutlinedButton(
        onClick = { context.startActivity(Intent(context, AmbientActivity::class.java)) },
        modifier = Modifier.fillMaxWidth(),
    ) { Text("Preview VISION Ambient") }
}

@Composable
private fun AodLimitationsNote() {
    Text(
        "VISION cannot force your device's native, screen-off Always-On Display — that control belongs to your " +
            "phone's manufacturer. \"Preview VISION Ambient\" shows VISION's own on-screen clock, which only works " +
            "while this screen is open; it is not equivalent to native AOD.",
        style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

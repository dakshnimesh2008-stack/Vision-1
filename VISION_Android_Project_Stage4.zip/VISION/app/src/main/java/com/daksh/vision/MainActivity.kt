package com.daksh.vision

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.daksh.vision.ui.VisionRoot

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        // System splash stays only while settings are genuinely loading.
        val splash = installSplashScreen()
        splash.setKeepOnScreenCondition { viewModel.state.value is UiState.Loading }
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        // Brand animation plays only on a fresh launch, never on rotation/return from another app.
        val coldStart = savedInstanceState == null
        setContent { VisionRoot(viewModel, playBrandIntro = coldStart) }
    }
}

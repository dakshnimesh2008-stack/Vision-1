package com.daksh.vision.ui.screens

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.daksh.vision.MainViewModel
import com.daksh.vision.aod.AodCapability
import com.daksh.vision.aod.AodMode
import com.daksh.vision.aod.AodState
import com.daksh.vision.aod.Schedule
import com.daksh.vision.aod.TimeOfDay
import com.daksh.vision.aod.Weekday
import com.daksh.vision.data.AppSettings
import com.daksh.vision.system.BatteryInfo

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ModePicker(mode: AodMode, onChange: (AodMode) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Mode", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AodMode.values().forEach { m ->
                FilterChip(selected = mode == m, onClick = { onChange(m) }, label = { Text(m.label) })
            }
        }
    }
}

@Composable
fun AlwaysOnCard(context: Context) {
    val hasSetting = remember { AodCapability.hasSystemAmbientSetting(context) }
    val enabled = remember { AodCapability.isSystemAmbientEnabled(context) }
    val intent = remember { AodCapability.systemAmbientSettingsIntent() }
    val canOpen = remember { AodCapability.canOpenSettings(context, intent) }
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Always On", style = MaterialTheme.typography.titleMedium)
            Text(
                if (hasSetting) {
                    "Your device exposes a native Ambient Display setting, currently ${if (enabled) "ON" else "OFF"}. " +
                        "VISION cannot change it directly, but can take you to the system screen."
                } else {
                    "This device doesn't expose a detectable native Ambient Display setting. Check your phone's " +
                        "Display settings directly, or use \"Preview VISION Ambient\" below as a fallback."
                },
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (canOpen) {
                OutlinedButton(onClick = { context.startActivity(intent) }) { Text("Open system Display settings") }
            }
        }
    }
}

@Composable
fun ChargingOnlyCard(battery: BatteryInfo?) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Charging Only", style = MaterialTheme.typography.titleMedium)
            Text(
                when {
                    battery == null -> "Charging status is unavailable on this device."
                    battery.charging -> "Your device is currently charging — this mode is active now."
                    else -> "Your device is not charging — this mode stays inactive until you plug in."
                },
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ScheduledCard(aod: AodState, settings: AppSettings, vm: MainViewModel) {
    val use24 = resolveUse24h(settings)
    val schedule = aod.schedule
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Scheduled", style = MaterialTheme.typography.titleMedium)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                TimePickerField("Start", schedule.start, use24, Modifier) { vm.setAodSchedule(schedule.copy(start = it)) }
                TimePickerField("End", schedule.end, use24, Modifier) { vm.setAodSchedule(schedule.copy(end = it)) }
            }
            if (schedule.start.minutesOfDay > schedule.end.minutesOfDay) {
                Text(
                    "This schedule crosses midnight: active from ${schedule.start.format(use24)} until ${schedule.end.format(use24)} the next day.",
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Text("Days", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Weekday.values().forEach { d ->
                    val sel = d in schedule.days
                    FilterChip(
                        selected = sel,
                        onClick = {
                            val days = if (sel) schedule.days - d else schedule.days + d
                            if (days.isNotEmpty()) vm.setAodSchedule(schedule.copy(days = days))
                        },
                        label = { Text(d.short) },
                    )
                }
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Enabled", Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                Switch(checked = schedule.enabled, onCheckedChange = { vm.setAodSchedule(schedule.copy(enabled = it)) })
            }
        }
    }
}

@Composable
fun TimePickerField(label: String, value: TimeOfDay, use24: Boolean, modifier: Modifier = Modifier, onChange: (TimeOfDay) -> Unit) {
    val android = androidx.compose.ui.platform.LocalContext.current
    Column(modifier) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        OutlinedButton(onClick = {
            android.app.TimePickerDialog(
                android, { _, h, m -> onChange(TimeOfDay(h, m)) }, value.hour, value.minute, use24,
            ).show()
        }) { Text(value.format(use24)) }
    }
}

@Composable
fun BatteryThresholdCard(aod: AodState, battery: BatteryInfo?, vm: MainViewModel) {
    var slider by remember(aod.batteryThreshold) { mutableFloatStateOf(aod.batteryThreshold.toFloat()) }
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Battery Threshold", style = MaterialTheme.typography.titleMedium)
            Text(
                "Active whenever battery is at or above ${slider.toInt()}%" +
                    if (battery != null) " (currently ${battery.percent}%)." else ".",
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            androidx.compose.foundation.layout.Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(20, 30, 40, 50).forEach { preset ->
                    OutlinedButton(onClick = { slider = preset.toFloat(); vm.setAodBatteryThreshold(preset) }) { Text("$preset%") }
                }
            }
            Slider(
                value = slider, onValueChange = { slider = it },
                onValueChangeFinished = { vm.setAodBatteryThreshold(slider.toInt()) },
                valueRange = 1f..100f, steps = 98,
            )
        }
    }
}

package com.daksh.vision.widgets

import android.appwidget.AppWidgetManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Reschedules the per-minute tick alarms and forces an immediate refresh after a reboot,
 * a manual time change, a time-zone change, or an app update - exactly the cases where a
 * widget would otherwise show a stale time.
 */
class WidgetSystemReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val manager = AppWidgetManager.getInstance(context)
        WidgetSize.values().forEach { size ->
            val ids = manager.getAppWidgetIds(VisionWidgetProvider.componentNameFor(context, size))
            if (ids.isNotEmpty()) {
                WidgetScheduler.schedule(context, size)
                ids.forEach { id ->
                    manager.updateAppWidget(id, WidgetRenderer.build(context, size, WidgetPrefs.load(context, id, size)))
                }
            }
        }
    }
}

package com.daksh.vision.widgets

import com.daksh.vision.clock.FormatChoice
import com.daksh.vision.clock.Palette

enum class WidgetSize(val label: String, val minWidthDp: Int, val minHeightDp: Int, val supportsDay: Boolean, val supportsDateByDefault: Boolean) {
    SMALL("Small", 60, 60, supportsDay = false, supportsDateByDefault = false),
    MEDIUM("Medium", 140, 90, supportsDay = false, supportsDateByDefault = true),
    LARGE("Large", 180, 150, supportsDay = true, supportsDateByDefault = true),
}

/** A widget "look" based on the in-app clock categories. RemoteViews cannot run continuous
 *  per-frame animation, so ANIMATED renders as a clearly-labelled static snapshot, not real motion. */
enum class WidgetLook(val label: String) {
    SIMPLE("Simple"),
    ANIMATED("Animated (static)"),
    BEAUTIFUL("Beautiful"),
}

data class WidgetConfig(
    val look: WidgetLook = WidgetLook.BEAUTIFUL,
    val main: Int = Palette.White.argb,
    val accent: Int = Palette.Blue.argb,
    val background: Int = Palette.Black.argb,
    val format: FormatChoice = FormatChoice.APP,
    val showDate: Boolean = true,
    val showDay: Boolean = false,
    val showBattery: Boolean = false,
) {
    fun encode(): String = listOf(look.name, main, accent, background, format.name, showDate, showDay, showBattery)
        .joinToString("|")

    companion object {
        fun defaultsFor(size: WidgetSize) = WidgetConfig(
            showDate = size.supportsDateByDefault,
            showDay = false,
            showBattery = size == WidgetSize.LARGE,
        )

        /** Never throws: any corrupt or outdated value falls back to [fallback]. */
        fun decode(raw: String?, fallback: WidgetConfig): WidgetConfig {
            if (raw.isNullOrBlank()) return fallback
            val p = raw.split("|")
            if (p.size != 8) return fallback
            return try {
                WidgetConfig(
                    look = WidgetLook.values().firstOrNull { it.name == p[0] } ?: return fallback,
                    main = p[1].toInt(), accent = p[2].toInt(), background = p[3].toInt(),
                    format = FormatChoice.values().firstOrNull { it.name == p[4] } ?: return fallback,
                    showDate = p[5].toStrictBool(), showDay = p[6].toStrictBool(), showBattery = p[7].toStrictBool(),
                )
            } catch (e: IllegalArgumentException) {
                fallback
            }
        }

        private fun String.toStrictBool(): Boolean = when (this) {
            "true" -> true
            "false" -> false
            else -> throw IllegalArgumentException("bad boolean")
        }
    }
}

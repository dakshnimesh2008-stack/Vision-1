package com.daksh.vision.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.daksh.vision.data.ThemeMode

val VisionAccentDark = Color(0xFF6EA8FF)
val VisionAccentLight = Color(0xFF2F5FD0)

private val Dark = darkColorScheme(
    primary = VisionAccentDark, onPrimary = Color(0xFF0B0F14),
    background = Color(0xFF0B0F14), onBackground = Color(0xFFE8ECF2),
    surface = Color(0xFF121821), onSurface = Color(0xFFE8ECF2),
    surfaceVariant = Color(0xFF1A2230), onSurfaceVariant = Color(0xFF9AA6B8),
    outline = Color(0xFF2A3445),
)
private val Light = lightColorScheme(
    primary = VisionAccentLight, onPrimary = Color.White,
    background = Color(0xFFF6F8FB), onBackground = Color(0xFF0E1420),
    surface = Color.White, onSurface = Color(0xFF0E1420),
    surfaceVariant = Color(0xFFE9EEF5), onSurfaceVariant = Color(0xFF55627A),
    outline = Color(0xFFD3DBE6),
)

private val VisionTypography = Typography(
    displayLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Thin, fontSize = 72.sp, letterSpacing = (-1).sp),
    headlineMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Light, fontSize = 28.sp),
    titleMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium, fontSize = 16.sp),
    bodyMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 14.sp),
    labelLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium, fontSize = 14.sp, letterSpacing = 0.4.sp),
)

private val VisionShapes = Shapes(
    small = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
    medium = androidx.compose.foundation.shape.RoundedCornerShape(20.dp),
    large = androidx.compose.foundation.shape.RoundedCornerShape(28.dp),
)

@Composable
fun VisionTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
    }
    MaterialTheme(
        colorScheme = if (dark) Dark else Light,
        typography = VisionTypography,
        shapes = VisionShapes,
        content = content,
    )
}

package com.daksh.vision.clock

import com.daksh.vision.clock.Palette as P

/** Offline clock catalogue: 8 Simple, 7 Animated, 10 Beautiful. All designs are original. */
object ClockLibrary {
    const val DEFAULT_ID = "minimal_digital"

    private fun cfg(
        main: Palette.Swatch = P.White, accent: Palette.Swatch = P.Blue,
        bg: Palette.Swatch = P.Black, text: Palette.Swatch = P.Grey,
        font: ClockFont = ClockFont.SANS,
        date: Boolean = true, seconds: Boolean = false, day: Boolean = false, analog: Boolean = false,
    ) = ClockConfig(
        main = main.argb, accent = accent.argb, background = bg.argb, text = text.argb,
        font = font, showDate = date, showSeconds = seconds, showDay = day, analog = analog,
    )

    val all: List<ClockStyle> = listOf(
        // ---------------- SIMPLE ----------------
        ClockStyle("minimal_digital", "Minimal Digital", ClockCategory.SIMPLE, Renderer.DIGITAL,
            cfg(), weight = 300, toggle = true, analogVariant = AnalogVariant.MINIMAL),
        ClockStyle("classic_analog", "Classic Analog", ClockCategory.SIMPLE, Renderer.ANALOG,
            cfg(main = P.Ink, accent = P.Red, bg = P.Paper, text = P.Ink, seconds = true, date = false, analog = true),
            analogVariant = AnalogVariant.CLASSIC, toggle = true),
        ClockStyle("large_digital", "Large Digital", ClockCategory.SIMPLE, Renderer.DIGITAL,
            cfg(date = false), weight = 400, sizeScale = 1.3f),
        ClockStyle("thin_type", "Thin Typography", ClockCategory.SIMPLE, Renderer.DIGITAL,
            cfg(main = P.Ice, accent = P.Ice, date = false, font = ClockFont.LIGHT), weight = 100, sizeScale = 1.25f),
        ClockStyle("bold_type", "Bold Typography", ClockCategory.SIMPLE, Renderer.DIGITAL,
            cfg(accent = P.Orange, date = false, font = ClockFont.BOLD), weight = 800, sizeScale = 0.9f, stacked = true),
        ClockStyle("minimal_date_time", "Date & Time", ClockCategory.SIMPLE, Renderer.DIGITAL,
            cfg(day = true), weight = 300, sizeScale = 0.9f),
        ClockStyle("compact", "Compact", ClockCategory.SIMPLE, Renderer.DIGITAL,
            cfg(bg = P.Graphite, date = false), weight = 500, sizeScale = 0.7f, toggle = true),
        ClockStyle("modern_numeral", "Modern Numeral", ClockCategory.SIMPLE, Renderer.ANALOG,
            cfg(accent = P.Mint, bg = P.Graphite, text = P.Ice, date = false),
            analogVariant = AnalogVariant.NUMERALS),

        // ---------------- ANIMATED ----------------
        ClockStyle("smooth_seconds", "Smooth Seconds", ClockCategory.ANIMATED, Renderer.ANALOG,
            cfg(accent = P.Orange, bg = P.Graphite, seconds = true, date = false),
            analogVariant = AnalogVariant.MINIMAL, smooth = true),
        ClockStyle("rotating_rings", "Rotating Rings", ClockCategory.ANIMATED, Renderer.RING,
            cfg(main = P.Blue, accent = P.Cyan, bg = P.Black, seconds = true, date = false), smooth = true),
        ClockStyle("digit_flow", "Digit Flow", ClockCategory.ANIMATED, Renderer.DIGITAL,
            cfg(seconds = true), weight = 300, animatedDigits = true),
        ClockStyle("aurora", "Aurora", ClockCategory.ANIMATED, Renderer.DIGITAL,
            cfg(accent = P.Violet, bg = P.Navy), weight = 300, decor = Decor.ANIM_GRADIENT, smooth = true),
        ClockStyle("orbit", "Orbit", ClockCategory.ANIMATED, Renderer.ORBIT,
            cfg(main = P.Gold, accent = P.Blue, bg = P.Black, seconds = true, date = false), smooth = true),
        ClockStyle("number_glide", "Number Glide", ClockCategory.ANIMATED, Renderer.DIGITAL,
            cfg(accent = P.Mint, date = false, font = ClockFont.BOLD), weight = 700, sizeScale = 0.8f,
            stacked = true, animatedDigits = true),
        ClockStyle("pulse", "Pulse", ClockCategory.ANIMATED, Renderer.DIGITAL,
            cfg(accent = P.Rose, bg = P.Plum), weight = 300, decor = Decor.PULSE, smooth = true),

        // ---------------- BEAUTIFUL ----------------
        ClockStyle("glass", "Glass", ClockCategory.BEAUTIFUL, Renderer.DIGITAL,
            cfg(accent = P.Violet, bg = P.Navy), weight = 200, decor = Decor.GLASS),
        ClockStyle("gradient", "Gradient", ClockCategory.BEAUTIFUL, Renderer.DIGITAL,
            cfg(accent = P.Rose, bg = P.Plum), weight = 300, sizeScale = 1.1f, decor = Decor.GRADIENT),
        ClockStyle("luxury", "Minimal Luxury", ClockCategory.BEAUTIFUL, Renderer.DIGITAL,
            cfg(main = P.Gold, accent = P.Gold, text = P.Grey, font = ClockFont.SERIF), weight = 400),
        ClockStyle("neon", "Neon Accent", ClockCategory.BEAUTIFUL, Renderer.DIGITAL,
            cfg(main = P.Cyan, accent = P.Cyan, text = P.Cyan, font = ClockFont.MONO), weight = 500, decor = Decor.GLOW),
        ClockStyle("soft_glow", "Soft Glow", ClockCategory.BEAUTIFUL, Renderer.DIGITAL,
            cfg(main = P.Ice, accent = P.Rose, bg = P.Plum), weight = 200, decor = Decor.GLOW),
        ClockStyle("progress_circle", "Progress Circle", ClockCategory.BEAUTIFUL, Renderer.RING,
            cfg(main = P.Mint, accent = P.Blue, bg = P.Forest, date = true)),
        ClockStyle("elegant_analog", "Elegant Analog", ClockCategory.BEAUTIFUL, Renderer.ANALOG,
            cfg(main = P.Ice, accent = P.Gold, bg = P.Graphite, seconds = true, date = false, analog = true),
            analogVariant = AnalogVariant.ELEGANT, toggle = true),
        ClockStyle("futuristic", "Futuristic Digital", ClockCategory.BEAUTIFUL, Renderer.DIGITAL,
            cfg(main = P.Mint, accent = P.Mint, text = P.Mint, bg = P.Forest, font = ClockFont.MONO, seconds = true),
            weight = 300, sizeScale = 1.05f, decor = Decor.GLOW),
        ClockStyle("typography_focus", "Typography Focus", ClockCategory.BEAUTIFUL, Renderer.DIGITAL,
            cfg(accent = P.Gold, day = true, font = ClockFont.SERIF), weight = 400, sizeScale = 1.15f, stacked = true),
        ClockStyle("premium_date_time", "Premium Date & Time", ClockCategory.BEAUTIFUL, Renderer.DIGITAL,
            cfg(main = P.Ice, accent = P.Gold, bg = P.Navy, day = true, font = ClockFont.SERIF),
            weight = 300, decor = Decor.GRADIENT),
    )

    val default: ClockStyle = all.first { it.id == DEFAULT_ID }
    fun byId(id: String?): ClockStyle? = all.firstOrNull { it.id == id }
    fun byCategory(c: ClockCategory): List<ClockStyle> = all.filter { it.category == c }
}

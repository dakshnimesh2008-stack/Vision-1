package com.daksh.vision

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.daksh.vision.aod.AodMode
import com.daksh.vision.aod.AodState
import com.daksh.vision.aod.CustomRule
import com.daksh.vision.aod.Schedule
import com.daksh.vision.clock.ClockConfig
import com.daksh.vision.clock.ClockState
import com.daksh.vision.data.AodRepository
import com.daksh.vision.data.AppSettings
import com.daksh.vision.data.ClockRepository
import com.daksh.vision.data.SettingsRepository
import com.daksh.vision.data.ThemeMode
import com.daksh.vision.data.TimeFormat
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

sealed interface UiState {
    data object Loading : UiState
    data class Ready(val settings: AppSettings, val clocks: ClockState, val aod: AodState) : UiState
    data class Error(val message: String) : UiState
}

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = SettingsRepository(app)
    private val clockRepo = ClockRepository(app)
    private val aodRepo = AodRepository(app)
    private val _state = MutableStateFlow<UiState>(UiState.Loading)
    val state: StateFlow<UiState> = _state
    private var job: Job? = null

    init { load() }

    /** Loads real persisted data. Ready is emitted as soon as DataStore responds: no artificial delay. */
    fun load() {
        job?.cancel()
        _state.value = UiState.Loading
        job = viewModelScope.launch {
            combine(repo.settings, clockRepo.state, aodRepo.state) { s, c, a -> UiState.Ready(s, c, a) as UiState }
                .catch { _state.value = UiState.Error(it.message ?: "Could not read saved data") }
                .collect { _state.value = it }
        }
    }

    fun setTheme(mode: ThemeMode) = viewModelScope.launch { repo.setTheme(mode) }
    fun setTimeFormat(format: TimeFormat) = viewModelScope.launch { repo.setTimeFormat(format) }
    fun resetAll() = viewModelScope.launch { repo.resetAll() }

    fun selectClock(id: String) = viewModelScope.launch { clockRepo.select(id) }
    fun saveClockConfig(id: String, cfg: ClockConfig) = viewModelScope.launch { clockRepo.save(id, cfg) }
    fun applyClock(id: String, cfg: ClockConfig) = viewModelScope.launch { clockRepo.apply(id, cfg) }

    fun setAodMode(mode: AodMode) = viewModelScope.launch { aodRepo.setMode(mode) }
    fun setAodSchedule(schedule: Schedule) = viewModelScope.launch { aodRepo.setSchedule(schedule) }
    fun setAodBatteryThreshold(percent: Int) = viewModelScope.launch { aodRepo.setBatteryThreshold(percent) }

    fun addAodRule(rule: CustomRule) = viewModelScope.launch {
        aodRepo.addRule(rule, currentRules())
    }
    fun updateAodRule(rule: CustomRule) = viewModelScope.launch {
        aodRepo.updateRule(rule, currentRules())
    }
    fun deleteAodRule(id: String) = viewModelScope.launch {
        aodRepo.deleteRule(id, currentRules())
    }
    fun setAodRuleEnabled(id: String, enabled: Boolean) = viewModelScope.launch {
        aodRepo.setRuleEnabled(id, enabled, currentRules())
    }

    private suspend fun currentRules(): List<CustomRule> =
        (state.value as? UiState.Ready)?.aod?.rules ?: aodRepo.state.first().rules
}

package com.daksh.vision.widgets

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent

/** Shared behaviour for all three widget sizes; each concrete provider only states its [size]. */
abstract class VisionWidgetProvider(private val size: WidgetSize) : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { id ->
            val config = WidgetPrefs.load(context, id, size)
            manager.updateAppWidget(id, WidgetRenderer.build(context, size, config))
        }
    }

    override fun onEnabled(context: Context) {
        // First instance of this size was just added.
        WidgetScheduler.schedule(context, size)
    }

    override fun onDisabled(context: Context) {
        // Last instance of this size was just removed.
        WidgetScheduler.cancel(context, size)
    }

    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        appWidgetIds.forEach { WidgetPrefs.clear(context, it) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (WidgetScheduler.matchesTick(intent, size)) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(componentNameFor(context, size))
            if (ids.isNotEmpty()) onUpdate(context, manager, ids)
        }
    }

    companion object {
        fun componentNameFor(context: Context, size: WidgetSize) = android.content.ComponentName(
            context,
            when (size) {
                WidgetSize.SMALL -> SmallClockWidget::class.java
                WidgetSize.MEDIUM -> MediumClockWidget::class.java
                WidgetSize.LARGE -> LargeClockWidget::class.java
            },
        )
    }
}

class SmallClockWidget : VisionWidgetProvider(WidgetSize.SMALL)
class MediumClockWidget : VisionWidgetProvider(WidgetSize.MEDIUM)
class LargeClockWidget : VisionWidgetProvider(WidgetSize.LARGE)

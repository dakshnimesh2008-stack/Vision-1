package com.daksh.vision.ui.screens

import android.appwidget.AppWidgetManager
import android.content.Context
import android.os.Build
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.daksh.vision.widgets.VisionWidgetProvider
import com.daksh.vision.widgets.WidgetConfig
import com.daksh.vision.widgets.WidgetConfigForm
import com.daksh.vision.widgets.WidgetPreview
import com.daksh.vision.widgets.WidgetSize

@Composable
fun WidgetsScreen() {
    var manualInstructions by rememberSaveable { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth().statusBarsPadding()) {
        Text(
            "Widgets", style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier.padding(start = 24.dp, top = 24.dp, end = 24.dp, bottom = 4.dp),
        )
        Text(
            "Pick a size, choose a look and colours, then add it to your home screen. Each widget you add can be " +
                "configured independently afterwards by long-pressing it and choosing \"Edit widget\".",
            style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 24.dp, bottom = 12.dp),
        )
        LazyColumn(
            contentPadding = androidx.compose.foundation.layout.PaddingValues(start = 24.dp, end = 24.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp),
        ) {
            items(WidgetSize.values().toList()) { size ->
                WidgetSizeCard(size, onUnsupported = { manualInstructions = true })
            }
        }
    }
    if (manualInstructions) ManualPinDialog(onDismiss = { manualInstructions = false })
}

@Composable
private fun WidgetSizeCard(size: WidgetSize, onUnsupported: () -> Unit) {
    var config by remember(size) { mutableStateOf(WidgetConfig.defaultsFor(size)) }
    val context = LocalContext.current

    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("${size.label} widget", style = MaterialTheme.typography.titleMedium)
            WidgetPreview(size, config, Modifier.fillMaxWidth().aspectRatio(if (size == WidgetSize.SMALL) 1.6f else 2.2f))
            WidgetConfigForm(size, config) { config = it }
            Button(
                onClick = { requestPin(context, size, onUnsupported) },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Add to Home Screen") }
            Text(
                "After adding, Android opens VISION's configuration screen automatically so this " +
                    "instance keeps its own colours and settings, separate from any other widget you add.",
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

private fun requestPin(context: Context, size: WidgetSize, onUnsupported: () -> Unit) {
    val manager = AppWidgetManager.getInstance(context)
    val provider = VisionWidgetProvider.componentNameFor(context, size)
    val supported = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && manager.isRequestPinAppWidgetSupported
    if (supported) {
        manager.requestPinAppWidget(provider, null, null)
    } else {
        onUnsupported()
    }
}

@Composable
private fun ManualPinDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add the widget manually") },
        text = {
            Text(
                "Your launcher doesn't support adding widgets directly from an app. To add one:\n\n" +
                    "1. Long-press an empty area of your home screen.\n" +
                    "2. Tap \"Widgets\".\n" +
                    "3. Find \"VISION\" in the list.\n" +
                    "4. Drag the size you want onto your home screen.\n\n" +
                    "VISION's configuration screen will open automatically so you can set its colours and look.",
            )
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Got it") } },
    )
}

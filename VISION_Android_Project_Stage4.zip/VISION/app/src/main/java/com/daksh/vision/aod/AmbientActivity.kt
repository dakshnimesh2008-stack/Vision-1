package com.daksh.vision.aod

import android.os.Bundle
import android.text.format.DateFormat
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.daksh.vision.clock.ClockState
import com.daksh.vision.clock.ClockView
import com.daksh.vision.data.ClockRepository
import com.daksh.vision.data.ThemeMode
import com.daksh.vision.system.rememberBattery
import com.daksh.vision.ui.theme.VisionTheme
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking

/**
 * VISION's own on-screen clock, launched only when the person taps "Preview Ambient" — it is
 * never triggered automatically from the background. It reuses the person's selected Stage 2
 * clock design full-screen and dim, and keeps the screen on only while this screen is open.
 * It is explicitly NOT the device's native, screen-off Always-On Display.
 */
class AmbientActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        // Config read is a one-shot (no Flow collection needed for a static preview screen).
        val clocks = runBlocking { ClockRepository(this@AmbientActivity).state.first() }
        setContent {
            VisionTheme(ThemeMode.DARK) {
                Surface(Modifier.fillMaxSize(), color = Color.Black) {
                    AmbientContent(clocks, onExit = { finish() })
                }
            }
        }
    }
}

@Composable
private fun AmbientContent(clocks: ClockState, onExit: () -> Unit) {
    val battery = rememberBattery()
    val style = clocks.selected
    val use24h = DateFormat.is24HourFormat(LocalContext.current)
    Box(
        Modifier.fillMaxSize().background(Color.Black).clickable(onClick = onExit),
        contentAlignment = Alignment.Center,
    ) {
        Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                "VISION AMBIENT — not your device's native Always-On Display",
                style = MaterialTheme.typography.labelLarge,
                color = Color(0xFF6B7280),
                textAlign = TextAlign.Center,
                modifier = Modifier.statusBarsPadding().padding(bottom = 32.dp),
            )
            ClockView(
                style, clocks.configFor(style), appUse24h = use24h, battery = battery,
                modifier = Modifier.fillMaxWidth().aspectRatio(1.4f),
            )
            Text(
                "Tap anywhere to exit",
                style = MaterialTheme.typography.bodyMedium, color = Color(0xFF6B7280),
                modifier = Modifier.padding(top = 32.dp),
            )
        }
    }
}

package com.daksh.vision.widgets

import android.content.Context

/**
 * Per-instance widget settings. Plain SharedPreferences (not DataStore) is used deliberately:
 * AppWidgetProvider.onUpdate/onReceive are synchronous callbacks, so configuration must be
 * readable without awaiting a coroutine. This is Android's documented pattern for widget config.
 */
object WidgetPrefs {
    private const val FILE = "vision_widget_prefs"
    private fun key(appWidgetId: Int) = "widget_$appWidgetId"

    fun load(context: Context, appWidgetId: Int, size: WidgetSize): WidgetConfig {
        val raw = context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString(key(appWidgetId), null)
        return WidgetConfig.decode(raw, WidgetConfig.defaultsFor(size))
    }

    fun save(context: Context, appWidgetId: Int, config: WidgetConfig) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putString(key(appWidgetId), config.encode()).apply()
    }

    fun clear(context: Context, appWidgetId: Int) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().remove(key(appWidgetId)).apply()
    }
}

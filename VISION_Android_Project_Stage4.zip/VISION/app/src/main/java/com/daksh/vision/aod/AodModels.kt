package com.daksh.vision.aod

enum class AodMode(val label: String) {
    OFF("Off"),
    ALWAYS_ON("Always On"),
    CHARGING_ONLY("Charging Only"),
    SCHEDULED("Scheduled"),
    BATTERY_THRESHOLD("Battery Threshold"),
    CUSTOM_RULES("Custom Rules"),
}

enum class Weekday(val short: String) { SUN("Sun"), MON("Mon"), TUE("Tue"), WED("Wed"), THU("Thu"), FRI("Fri"), SAT("Sat") }

/** Minutes since midnight, 0..1439. Keeping schedule as plain ints avoids any time-zone ambiguity. */
data class TimeOfDay(val hour: Int, val minute: Int) {
    val minutesOfDay: Int get() = hour * 60 + minute
    fun format(use24h: Boolean): String {
        val h = if (use24h) hour else ((hour % 12).let { if (it == 0) 12 else it })
        val ap = if (use24h) "" else if (hour < 12) " AM" else " PM"
        return "%02d:%02d%s".format(h, minute, ap)
    }
    fun encode() = "$hour:$minute"
    companion object {
        fun decode(raw: String, fallback: TimeOfDay): TimeOfDay {
            val p = raw.split(":")
            if (p.size != 2) return fallback
            val h = p[0].toIntOrNull() ?: return fallback
            val m = p[1].toIntOrNull() ?: return fallback
            if (h !in 0..23 || m !in 0..59) return fallback
            return TimeOfDay(h, m)
        }
    }
}

data class Schedule(
    val start: TimeOfDay = TimeOfDay(22, 0),
    val end: TimeOfDay = TimeOfDay(6, 0),
    val days: Set<Weekday> = Weekday.values().toSet(),
    val enabled: Boolean = true,
) {
    /** Handles overnight ranges (e.g. 22:00 -> 06:00) by checking both the start day and the day before. */
    fun isActiveAt(minutesOfDay: Int, weekday: Weekday, previousWeekday: Weekday): Boolean {
        if (!enabled) return false
        val s = start.minutesOfDay
        val e = end.minutesOfDay
        return if (s == e) {
            weekday in days // a full-day window
        } else if (s < e) {
            weekday in days && minutesOfDay in s until e
        } else {
            // Overnight: active from `start` to midnight (counts as `weekday`'s window),
            // and from midnight to `end` (counts as the window that started the *previous* day).
            (weekday in days && minutesOfDay >= s) || (previousWeekday in days && minutesOfDay < e)
        }
    }

    fun encode(): String = "${start.encode()}~${end.encode()}~${days.joinToString(",") { it.name }}~$enabled"

    companion object {
        fun decode(raw: String?, fallback: Schedule): Schedule {
            if (raw.isNullOrBlank()) return fallback
            val p = raw.split("~")
            if (p.size != 4) return fallback
            val start = TimeOfDay.decode(p[0], fallback.start)
            val end = TimeOfDay.decode(p[1], fallback.end)
            val days = p[2].split(",").mapNotNull { n -> Weekday.values().firstOrNull { it.name == n } }.toSet()
            val enabled = p[3].toBooleanStrictOrNull() ?: return fallback
            if (days.isEmpty()) return fallback
            return Schedule(start, end, days, enabled)
        }
    }
}

enum class ConditionType(val label: String) {
    CHARGING("Charging"),
    BATTERY_ABOVE("Battery above"),
    BATTERY_BELOW("Battery below"),
    TIME_BETWEEN("Current time between"),
    SCHEDULE_ACTIVE("Schedule is active"),
}

data class Condition(
    val type: ConditionType = ConditionType.CHARGING,
    val boolValue: Boolean = true,
    val intValue: Int = 30,
    val timeStart: TimeOfDay = TimeOfDay(22, 0),
    val timeEnd: TimeOfDay = TimeOfDay(6, 0),
) {
    fun encode(): String = "${type.name}|$boolValue|$intValue|${timeStart.encode()}|${timeEnd.encode()}"
    companion object {
        fun decode(raw: String): Condition? {
            val p = raw.split("|")
            if (p.size != 5) return null
            val type = ConditionType.values().firstOrNull { it.name == p[0] } ?: return null
            val bool = p[1].toBooleanStrictOrNull() ?: return null
            val int = p[2].toIntOrNull() ?: return null
            val ts = TimeOfDay.decode(p[3], TimeOfDay(22, 0))
            val te = TimeOfDay.decode(p[4], TimeOfDay(6, 0))
            return Condition(type, bool, int, ts, te)
        }
    }
}

enum class Logic { AND, OR }

data class CustomRule(
    val id: String,
    val name: String,
    val logic: Logic = Logic.AND,
    val conditions: List<Condition> = listOf(Condition()),
    val enabled: Boolean = true,
) {
    fun encode(): String {
        val condPart = conditions.joinToString(";;") { it.encode() }
        return "$id§§$name§§${logic.name}§§$condPart§§$enabled"
    }
    companion object {
        fun decode(raw: String): CustomRule? {
            val p = raw.split("§§")
            if (p.size != 5) return null
            val logic = Logic.values().firstOrNull { it.name == p[2] } ?: return null
            val conditions = p[3].split(";;").mapNotNull { if (it.isBlank()) null else Condition.decode(it) }
            val enabled = p[4].toBooleanStrictOrNull() ?: return null
            if (conditions.isEmpty()) return null
            return CustomRule(p[0], p[1], logic, conditions, enabled)
        }
    }
}

data class AodState(
    val mode: AodMode = AodMode.OFF,
    val schedule: Schedule = Schedule(),
    val batteryThreshold: Int = 30,
    val rules: List<CustomRule> = emptyList(),
)

/** Real-world facts the rule engine and each mode evaluate against. Supplied by the caller, never faked. */
data class AodContext(
    val charging: Boolean,
    val batteryPercent: Int?,
    val minutesOfDay: Int,
    val weekday: Weekday,
    val previousWeekday: Weekday,
)

/** Per-condition and overall result, so the UI can show exactly which conditions are satisfied. */
data class ConditionResult(val condition: Condition, val satisfied: Boolean)
data class RuleResult(val rule: CustomRule, val conditionResults: List<ConditionResult>, val satisfied: Boolean)

package com.daksh.vision.aod

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class AodModelsCodecTest {
    @Test fun conditionEncodeDecodeRoundTrip() {
        val c = Condition(ConditionType.BATTERY_BELOW, boolValue = false, intValue = 15, timeStart = TimeOfDay(1, 2), timeEnd = TimeOfDay(3, 4))
        assertEquals(c, Condition.decode(c.encode()))
    }

    @Test fun conditionDecodeRejectsGarbage() {
        assertNull(Condition.decode("nonsense"))
        assertNull(Condition.decode("BAD_TYPE|true|10|1:2|3:4"))
    }

    @Test fun ruleEncodeDecodeRoundTrip() {
        val rule = CustomRule(
            id = "abc-123", name = "Night mode", logic = Logic.OR,
            conditions = listOf(Condition(ConditionType.CHARGING), Condition(ConditionType.BATTERY_ABOVE, intValue = 40)),
            enabled = false,
        )
        assertEquals(rule, CustomRule.decode(rule.encode()))
    }

    @Test fun ruleDecodeRejectsGarbageAndEmptyConditions() {
        assertNull(CustomRule.decode("not a rule"))
        assertNull(CustomRule.decode("id§§name§§AND§§§§true")) // empty condition list
    }

    @Test fun timeOfDayFormatting() {
        assertEquals("14:05", TimeOfDay(14, 5).format(use24h = true))
        assertEquals("02:05 PM", TimeOfDay(14, 5).format(use24h = false))
        assertEquals("12:00 AM", TimeOfDay(0, 0).format(use24h = false))
        assertEquals("12:00 PM", TimeOfDay(12, 0).format(use24h = false))
    }
}

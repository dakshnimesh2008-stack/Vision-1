package com.daksh.vision.widgets

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class WidgetSizeTest {
    @Test fun onlyLargeSupportsDay() {
        assertFalse(WidgetSize.SMALL.supportsDay)
        assertFalse(WidgetSize.MEDIUM.supportsDay)
        assertTrue(WidgetSize.LARGE.supportsDay)
    }

    @Test fun smallHasNoDateByDefault() {
        assertFalse(WidgetSize.SMALL.supportsDateByDefault)
        assertTrue(WidgetSize.MEDIUM.supportsDateByDefault)
        assertTrue(WidgetSize.LARGE.supportsDateByDefault)
    }

    @Test fun minimumSizesIncreaseWithTier() {
        assertTrue(WidgetSize.MEDIUM.minWidthDp > WidgetSize.SMALL.minWidthDp)
        assertTrue(WidgetSize.LARGE.minWidthDp > WidgetSize.MEDIUM.minWidthDp)
    }
}

package com.daksh.vision.clock

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ClockConfigTest {
    private val fallback = ClockLibrary.default.defaults

    @Test fun encodeDecodeRoundTrip() {
        val c = fallback.copy(main = Palette.Gold.argb, font = ClockFont.SERIF, format = FormatChoice.H12,
            showSeconds = true, showDay = true, showBattery = true, analog = true)
        assertEquals(c, ClockConfig.decode(c.encode(), fallback))
    }

    @Test fun nullBlankAndGarbageFallBack() {
        assertEquals(fallback, ClockConfig.decode(null, fallback))
        assertEquals(fallback, ClockConfig.decode("", fallback))
        assertEquals(fallback, ClockConfig.decode("not a config", fallback))
        assertEquals(fallback, ClockConfig.decode("1|2|3|4|SANS|APP|true|false|false|false", fallback)) // too short
    }

    @Test fun badEnumOrNumberOrBooleanFallBack() {
        val ok = fallback.encode().split("|").toMutableList()
        fun with(i: Int, v: String) = ok.toMutableList().also { it[i] = v }.joinToString("|")
        assertEquals(fallback, ClockConfig.decode(with(4, "COMIC"), fallback))
        assertEquals(fallback, ClockConfig.decode(with(5, "H99"), fallback))
        assertEquals(fallback, ClockConfig.decode(with(0, "red"), fallback))
        assertEquals(fallback, ClockConfig.decode(with(6, "yes"), fallback))
    }

    @Test fun resolve24() {
        assertTrue(fallback.copy(format = FormatChoice.H24).resolve24(false))
        assertFalse(fallback.copy(format = FormatChoice.H12).resolve24(true))
        assertTrue(fallback.copy(format = FormatChoice.APP).resolve24(true))
        assertFalse(fallback.copy(format = FormatChoice.APP).resolve24(false))
    }
}

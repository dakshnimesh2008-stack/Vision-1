package com.daksh.vision.widgets

import com.daksh.vision.clock.FormatChoice
import com.daksh.vision.clock.Palette
import org.junit.Assert.assertEquals
import org.junit.Test

class WidgetConfigTest {
    private val fallback = WidgetConfig.defaultsFor(WidgetSize.MEDIUM)

    @Test fun encodeDecodeRoundTrip() {
        val c = fallback.copy(
            look = WidgetLook.ANIMATED, main = Palette.Gold.argb, accent = Palette.Rose.argb,
            background = Palette.Navy.argb, format = FormatChoice.H24,
            showDate = false, showDay = true, showBattery = true,
        )
        assertEquals(c, WidgetConfig.decode(c.encode(), fallback))
    }

    @Test fun nullBlankAndGarbageFallBack() {
        assertEquals(fallback, WidgetConfig.decode(null, fallback))
        assertEquals(fallback, WidgetConfig.decode("", fallback))
        assertEquals(fallback, WidgetConfig.decode("nonsense", fallback))
        assertEquals(fallback, WidgetConfig.decode("SIMPLE|1|2|3|APP|true|false", fallback)) // too short
    }

    @Test fun badEnumOrBooleanFallsBack() {
        val parts = fallback.encode().split("|").toMutableList()
        fun with(i: Int, v: String) = parts.toMutableList().also { it[i] = v }.joinToString("|")
        assertEquals(fallback, WidgetConfig.decode(with(0, "WEIRD"), fallback))
        assertEquals(fallback, WidgetConfig.decode(with(4, "H99"), fallback))
        assertEquals(fallback, WidgetConfig.decode(with(5, "maybe"), fallback))
    }

    @Test fun defaultsDifferBySize() {
        assertEquals(false, WidgetConfig.defaultsFor(WidgetSize.SMALL).showDate)
        assertEquals(true, WidgetConfig.defaultsFor(WidgetSize.MEDIUM).showDate)
        assertEquals(true, WidgetConfig.defaultsFor(WidgetSize.LARGE).showDate)
        assertEquals(false, WidgetConfig.defaultsFor(WidgetSize.MEDIUM).showBattery)
        assertEquals(true, WidgetConfig.defaultsFor(WidgetSize.LARGE).showBattery)
    }
}

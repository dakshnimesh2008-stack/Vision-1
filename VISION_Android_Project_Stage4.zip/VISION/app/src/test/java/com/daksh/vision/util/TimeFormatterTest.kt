package com.daksh.vision.util

import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.LocalDateTime
import java.util.Locale

class TimeFormatterTest {
    private val t = LocalDateTime.of(2026, 10, 12, 21, 5, 9)
    private val us = Locale.US

    @Test fun format24h() = assertEquals("21:05", TimeFormatter.time(t, true, false, us))
    @Test fun format24hSeconds() = assertEquals("21:05:09", TimeFormatter.time(t, true, true, us))
    @Test fun format12h() = assertEquals("9:05", TimeFormatter.time(t, false, false, us))
    @Test fun format12hSeconds() = assertEquals("9:05:09", TimeFormatter.time(t, false, true, us))
    @Test fun amPmHiddenIn24h() = assertEquals("", TimeFormatter.amPm(t, true, us))
    @Test fun amPmShownIn12h() = assertEquals("PM", TimeFormatter.amPm(t, false, us))
    @Test fun dateText() = assertEquals("Monday, 12 October", TimeFormatter.date(t, us))
    @Test fun midnight12h() =
        assertEquals("12:00", TimeFormatter.time(LocalDateTime.of(2026, 1, 1, 0, 0), false, false, us))
    @Test fun dayNameOnly() = assertEquals("Monday", TimeFormatter.dayName(t, us))
    @Test fun dateShortOnly() = assertEquals("12 October", TimeFormatter.dateShort(t, us))
}

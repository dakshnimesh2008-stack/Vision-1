package com.daksh.vision.aod

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ScheduleTest {
    @Test fun sameDayWindow() {
        val s = Schedule(TimeOfDay(9, 0), TimeOfDay(17, 0), setOf(Weekday.MON))
        assertTrue(s.isActiveAt(12 * 60, Weekday.MON, Weekday.SUN))
        assertFalse(s.isActiveAt(8 * 60, Weekday.MON, Weekday.SUN))
        assertFalse(s.isActiveAt(18 * 60, Weekday.MON, Weekday.SUN))
        assertFalse(s.isActiveAt(12 * 60, Weekday.TUE, Weekday.MON)) // wrong day
    }

    @Test fun overnightWindowCrossesMidnight() {
        val s = Schedule(TimeOfDay(22, 0), TimeOfDay(6, 0), setOf(Weekday.FRI))
        // 23:00 on Friday itself: active (after start, same day as window start)
        assertTrue(s.isActiveAt(23 * 60, Weekday.FRI, Weekday.THU))
        // 02:00 on Saturday: active (before end, previous day was Friday which is in days)
        assertTrue(s.isActiveAt(2 * 60, Weekday.SAT, Weekday.FRI))
        // 02:00 on Sunday: previous day Saturday is NOT in days -> inactive
        assertFalse(s.isActiveAt(2 * 60, Weekday.SUN, Weekday.SAT))
        // 12:00 noon Friday: outside the overnight window -> inactive
        assertFalse(s.isActiveAt(12 * 60, Weekday.FRI, Weekday.THU))
    }

    @Test fun disabledScheduleIsNeverActive() {
        val s = Schedule(TimeOfDay(0, 0), TimeOfDay(0, 0), Weekday.values().toSet(), enabled = false)
        assertFalse(s.isActiveAt(12 * 60, Weekday.MON, Weekday.SUN))
    }

    @Test fun fullDayWindowWhenStartEqualsEnd() {
        val s = Schedule(TimeOfDay(10, 0), TimeOfDay(10, 0), setOf(Weekday.WED))
        assertTrue(s.isActiveAt(0, Weekday.WED, Weekday.TUE))
        assertTrue(s.isActiveAt(23 * 60 + 59, Weekday.WED, Weekday.TUE))
        assertFalse(s.isActiveAt(12 * 60, Weekday.THU, Weekday.WED))
    }

    @Test fun encodeDecodeRoundTrip() {
        val s = Schedule(TimeOfDay(21, 15), TimeOfDay(5, 45), setOf(Weekday.SAT, Weekday.SUN), enabled = false)
        assertEquals(s, Schedule.decode(s.encode(), Schedule()))
    }

    @Test fun decodeFallsBackOnCorruptData() {
        val fallback = Schedule()
        assertEquals(fallback, Schedule.decode(null, fallback))
        assertEquals(fallback, Schedule.decode("garbage", fallback))
        assertEquals(fallback, Schedule.decode("25:99~6:0~MON~true", fallback)) // invalid hour/minute
        assertEquals(fallback, Schedule.decode("9:0~17:0~~true", fallback)) // no days
    }
}

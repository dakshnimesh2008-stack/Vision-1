package com.daksh.vision.clock

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ClockLibraryTest {
    @Test fun categoryCounts() {
        assertEquals(8, ClockLibrary.byCategory(ClockCategory.SIMPLE).size)
        assertEquals(7, ClockLibrary.byCategory(ClockCategory.ANIMATED).size)
        assertEquals(10, ClockLibrary.byCategory(ClockCategory.BEAUTIFUL).size)
        assertEquals(25, ClockLibrary.all.size)
    }

    @Test fun idsAndNamesAreUnique() {
        assertEquals(ClockLibrary.all.size, ClockLibrary.all.map { it.id }.toSet().size)
        assertEquals(ClockLibrary.all.size, ClockLibrary.all.map { it.name }.toSet().size)
    }

    @Test fun defaultExistsAndLookupWorks() {
        assertEquals(ClockLibrary.DEFAULT_ID, ClockLibrary.default.id)
        assertNotNull(ClockLibrary.byId("glass"))
        assertNull(ClockLibrary.byId("does_not_exist"))
        assertNull(ClockLibrary.byId(null))
    }

    @Test fun everyDefaultSurvivesRoundTrip() {
        ClockLibrary.all.forEach { s ->
            assertEquals(s.id, s.defaults, ClockConfig.decode(s.defaults.encode(), s.defaults))
        }
    }

    @Test fun analogClocksDoNotOfferFontOrFormat() {
        ClockLibrary.all.forEach { s ->
            val o = s.options(s.defaults)
            if (s.effectiveRenderer(s.defaults) == Renderer.ANALOG) {
                assertFalse(s.id, Option.FONT in o); assertFalse(s.id, Option.FORMAT in o)
            } else {
                assertTrue(s.id, Option.FONT in o); assertTrue(s.id, Option.FORMAT in o)
            }
            assertEquals(s.id, s.toggle, Option.PRESENTATION in o)
        }
    }

    @Test fun toggleSwitchesRenderer() {
        val s = ClockLibrary.byId("minimal_digital")!!
        assertEquals(Renderer.DIGITAL, s.effectiveRenderer(s.defaults))
        assertEquals(Renderer.ANALOG, s.effectiveRenderer(s.defaults.copy(analog = true)))
    }

    @Test fun nonToggleClocksIgnoreAnalogFlag() {
        val s = ClockLibrary.byId("glass")!!
        assertEquals(Renderer.DIGITAL, s.effectiveRenderer(s.defaults.copy(analog = true)))
    }

    @Test fun unknownSelectedIdFallsBackToDefault() {
        assertEquals(ClockLibrary.default, ClockState("gone", emptyMap()).selected)
    }

    @Test fun missingConfigFallsBackToStyleDefaults() {
        val s = ClockLibrary.byId("neon")!!
        assertEquals(s.defaults, ClockState("neon", emptyMap()).configFor(s))
    }
}

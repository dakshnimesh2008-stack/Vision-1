# VISION — Time. Your Way.

Native Android (Kotlin + Jetpack Compose + Material 3) clock customization app. Package: `com.daksh.vision`.

## Status: Stage 5 of 5 — finalized

This pass started from a reported GitHub Actions build failure, fixed it, then did a full
cross-stage review and quality pass. It did **not** rebuild anything from scratch — every
working feature from Stages 1–4 (loading screen, navigation, 25 clocks, customization, real
home-screen widgets, Smart AOD) is intact; what follows is what changed and what didn't.

## PART 1 — The reported build error, and what it actually was

```
WidgetsScreen.kt:49:51 — Cannot find a parameter with this name: bottom
```

**Cause:** `Modifier.padding(horizontal = 24.dp, bottom = 12.dp)`. Compose's `Modifier.padding()`
has distinct overloads — `padding(all: Dp)`, `padding(horizontal: Dp, vertical: Dp)`, and
`padding(start: Dp, top: Dp, end: Dp, bottom: Dp)` — and they don't mix: naming `horizontal`
selects the two-argument overload, which has no `bottom` parameter at all. That's exactly what
the compiler reported.

**Fix:** `Modifier.padding(start = 24.dp, end = 24.dp, bottom = 12.dp)` — the four-argument
overload, which does accept `bottom`, with `top` defaulting to `0.dp`. This preserves the
original intent (24dp on each side, 12dp below, no gap above) exactly.

**Checked for more of the same:** searched every `.padding(` call in the project for the same
overload-mixing mistake. No other instance existed.

## PART 2 — What Stage 5 found and fixed beyond the reported error

Four more real, verifiable bugs were found during the cross-stage review (not hypothetical —
each is the kind of mistake that fails a real compile or produces wrong behavior, and each fix
is covered by the reasoning or tests below):

1. **`SCHEDULE_ACTIVE` custom-rule condition checked the wrong thing.** It evaluated a stored
   `boolValue` flag — effectively always `true` and never actually tied to the real schedule —
   instead of checking whether the current time is inside the Scheduled-mode time window. Fixed:
   `AodEngine.evaluateCondition` now takes the real `Schedule` and calls its own
   `isActiveAt(...)` window check, the same logic already used (and tested) for Scheduled mode
   itself. Three new regression tests cover this exactly: satisfied inside the window and not
   outside it regardless of the old flag's value, respecting a disabled schedule, and an
   overnight (midnight-crossing) window used from inside a custom rule. The UI text that
   described this condition as "Schedule is enabled" was also corrected, in the condition list,
   the rule-editor explanation, and the live per-condition description shown on each rule card,
   since the old wording was part of what made the bug easy to miss.
2. **A local variable literally named `android` shadowed the `android` package** in
   `TimePickerField` (used by both Scheduled mode and the Custom Rules time-range condition).
   `val android = LocalContext.current` followed by `android.app.TimePickerDialog(...)` would
   have the compiler try to resolve `.app` as a member of the `Context` value, not as the
   `android.app` package — a real compile error of the same family as the reported one. Fixed by
   renaming the variable to `context` and importing `TimePickerDialog` properly instead of
   relying on a now-removed fully-qualified reference.
3. **A silent logic bug in Battery Threshold mode:** when the battery percentage is unreadable
   (`null`), the mode previously defaulted to "always above threshold" (`101 >= threshold`),
   which is backwards — an unknown value should never satisfy a floor. Fixed to return `false`
   when the battery percentage is unavailable. Caught by, and verified against, a dedicated unit
   test (`batteryThresholdUsesRealPercent`'s null case) and independently cross-checked in Python
   against the same test cases, since no JVM is available here to run the real test.
4. **`AmbientActivity` blocked the main thread on launch** with
   `runBlocking { ClockRepository(...).state.first() }` to read the saved clock before the first
   frame. Replaced with `collectAsState(initial = ...)` so the Flow is collected asynchronously,
   with a sensible first-frame default (the same default clock the rest of the app falls back to)
   instead of a blocking read.

**Cleanup also done:** 11 confirmed-unused imports removed across 9 files (verified individually
— each symbol checked for real usage before removal, not just flagged); the project-wide
duplicate-placeholder file from earlier stages was already gone (confirmed, not re-added).

## PART 3 — Cross-stage verification (what was checked, and how)

No Kotlin compiler, Android SDK, or network access exists in this environment (confirmed: no
`gradle`/`kotlinc` on PATH, no cached SDK, network calls time out). Nothing here was compiled or
executed. What *was* done, and is independently checkable by reading the code:

- **Clock library:** confirmed 25 designs present (Simple 8 / Animated 7 / Beautiful 10), unique
  IDs and names, every design's default config round-trips through its own encode/decode, every
  analog/digital toggle resolves its renderer correctly — all via `ClockLibraryTest` /
  `ClockConfigTest`, unchanged from Stage 2 and re-verified for consistency this pass.
- **Widgets:** three `AppWidgetProvider`s (Small/Medium/Large) with distinct info XML, layouts,
  and manifest `<receiver>` entries confirmed present and matching; per-`appWidgetId` SharedPreferences
  confirmed independent; config encode/decode and per-size defaults covered by
  `WidgetConfigTest`/`WidgetSizeTest`.
- **Smart AOD:** every mode's logic (Off/Always On/Charging Only/Scheduled/Battery
  Threshold/Custom Rules), the AND/OR rule engine, and — new this pass — the corrected
  `SCHEDULE_ACTIVE` condition, covered by `AodEngineTest`/`ScheduleTest`/`AodModelsCodecTest`
  (13 + 6 + 5 test functions). The trickiest logic (overnight-schedule evaluation, the
  battery-threshold null case, and the new `SCHEDULE_ACTIVE` fix) was independently re-implemented
  in Python from the same specification and checked against the same cases the Kotlin tests use;
  all matched.
- **Whole-project static consistency** (run after every change in this pass, not just once):
  every brace/paren balanced across all 46 Kotlin files, no duplicate top-level declarations in
  the same package, every `import com.daksh.vision.*` resolves to a real declaration, every XML
  file (including the manifest) well-formed, every `R.id.*` used from Kotlin exists in the layout
  that renders it, every `@string` reference resolves, every `MainViewModel` method called from
  UI code matches its real signature, every `Modifier.weight()` call sits inside a matching
  `Row`/`Column` scope, and a project-wide search for the exact two bug patterns found (padding-
  overload mixing, package-name-shadowing locals) turned up no further instances.
- **Not possible here:** an actual `gradle testDebugUnitTest` / `gradle assembleDebug` run, an
  emulator or device run, or visual confirmation of how any clock or widget actually renders.
  These happen for the first time in GitHub Actions / on your phone — see Build below.

## Build from a phone (GitHub Actions)
1. Create a GitHub repo and upload this folder's contents (keep the `.github` folder).
2. Actions tab → "Build VISION debug APK" → Run workflow (also runs on every push). It runs unit
   tests, then builds.
3. Download the `VISION-debug-apk` artifact, unzip it, install `app-debug.apk`.

No Gradle wrapper is needed; the workflow installs Gradle 8.7. Versions: AGP 8.5.2, Kotlin 1.9.24,
Compose BOM 2024.06.00, compile/target SDK 34, min SDK 26. If this build still fails, the error
log is the fastest way to get it fixed — paste it back and the exact line will be addressed the
same way the two compile errors in this pass were.

## Widget setup
Open VISION → **Widgets** → pick a size, choose a look and colours → **Add to Home Screen**
(uses `requestPinAppWidget`; a manual-instructions dialog appears if your launcher doesn't
support it). Android opens VISION's configuration screen automatically for each new instance,
so multiple widgets of the same size can have different colours/settings independently.

## Smart AOD limitations
No third-party app — VISION included — can force a true, screen-off Always-On Display; that
belongs to the device manufacturer's system UI. Always On mode detects the real Ambient Display
setting where the device exposes it and links to system Display settings; it cannot flip that
setting itself. **"Preview VISION Ambient"** is VISION's own dim, full-screen clock, explicitly
labelled on-screen as not the device's native AOD, launched only by an explicit tap — never
automatically from the background (Android doesn't allow that without permissions VISION
deliberately doesn't request: no overlay, no Accessibility Service, no device admin, no root).
Smart AOD runs no background service or alarm; status is evaluated live from real battery/clock
state whenever the screen is open, which avoids battery drain and background-execution
restrictions entirely rather than working around them.

## Required permissions
- `RECEIVE_BOOT_COMPLETED` (Stage 3): lets home-screen widgets resume ticking after a restart.
  Explained in Settings → Permissions.
- Smart AOD needs no new permission: battery/charging state needs none on modern Android, the one
  secure setting it reads needs none to read, and it opens system Settings via a normal Intent.
- No internet, accounts, ads, or analytics, anywhere in the app.

## Test results
54 JUnit test functions across 8 files, all pure-Kotlin (no Android framework dependency):
`TimeFormatterTest` (10), `ClockConfigTest` (4), `ClockLibraryTest` (9), `ScheduleTest` (6),
`AodEngineTest` (13, including 3 new regression tests for the `SCHEDULE_ACTIVE` fix),
`AodModelsCodecTest` (5), `WidgetConfigTest` (4), `WidgetSizeTest` (3). **Not run here** — no JVM
with the project's dependencies available in this environment. They run for the first time with
`gradle testDebugUnitTest`, which the CI workflow runs automatically before every build.

## Known issues
- Nothing has been compiled here; a real `gradle build` may still surface an error this
  environment's text-only review couldn't catch (version incompatibility, a resource conflict,
  etc.). If it does, the build log pinpoints it exactly the way this pass's reported error did.
- Always On's capability detection depends on a secure setting key common on AOSP/Pixel-style
  builds but not guaranteed on every OEM skin; where absent, VISION says so rather than guessing.
- Clock and widget visuals are unverified on an actual screen/launcher.
- "Preview VISION Ambient" only works while its screen is open and the app is reachable, by
  design — see Smart AOD limitations above.

## How to install and test the APK
No APK is included — this environment cannot run an Android build (no SDK, no network to fetch
one). Build it via GitHub Actions as described above, then:
1. Transfer `app-debug.apk` to your phone (or download directly if you open the Actions page on
   your phone).
2. Open it; allow "install unknown apps" for your browser/files app if prompted.
3. Walk through Home → Clocks → Widgets → Smart AOD → Settings to exercise each stage.

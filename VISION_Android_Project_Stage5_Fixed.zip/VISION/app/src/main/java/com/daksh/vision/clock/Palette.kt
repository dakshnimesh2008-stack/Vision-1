package com.daksh.vision.clock

/** Restrained colour choices offered in the customizer. */
object Palette {
    data class Swatch(val name: String, val argb: Int)
    private fun s(n: String, v: Long) = Swatch(n, v.toInt())

    val White = s("White", 0xFFFFFFFF); val Ice = s("Ice", 0xFFE8ECF2); val Blue = s("Blue", 0xFF6EA8FF)
    val Cyan = s("Cyan", 0xFF5CE1E6); val Mint = s("Mint", 0xFF7CE0B1); val Gold = s("Gold", 0xFFD9B26F)
    val Rose = s("Rose", 0xFFFF8FA3); val Violet = s("Violet", 0xFFB69CFF); val Orange = s("Orange", 0xFFFFA45C)
    val Red = s("Red", 0xFFD64545); val Ink = s("Ink", 0xFF0E1420); val Grey = s("Grey", 0xFF9AA6B8)
    val Black = s("Black", 0xFF0B0F14); val Graphite = s("Graphite", 0xFF1A2230); val Navy = s("Navy", 0xFF0F1B33)
    val Plum = s("Plum", 0xFF1E1230); val Forest = s("Forest", 0xFF0E2219); val Paper = s("Paper", 0xFFF6F8FB)

    val foreground = listOf(White, Ice, Blue, Cyan, Mint, Gold, Rose, Violet, Orange, Red, Ink)
    val textColors = listOf(Grey, Ice, White, Blue, Gold, Rose, Ink)
    val backgrounds = listOf(Black, Graphite, Navy, Plum, Forest, Paper, White)
    fun nameOf(argb: Int): String =
        (foreground + textColors + backgrounds).firstOrNull { it.argb == argb }?.name ?: "Custom"
}

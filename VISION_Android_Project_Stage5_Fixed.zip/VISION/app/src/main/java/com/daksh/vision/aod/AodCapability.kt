package com.daksh.vision.aod

import android.content.Context
import android.content.Intent
import android.provider.Settings

/**
 * Reports what this specific device genuinely allows. VISION never claims to force a true,
 * screen-off Always-On Display: that control belongs to the OEM's system UI. What VISION *can*
 * legitimately do is detect the official Ambient Display setting where exposed, open the right
 * system settings screen, and drive its own in-app/widget behaviour from real device signals
 * (charging, battery, schedule, custom rules).
 */
object AodCapability {
    /** True on devices that expose the standard "Ambient display" / "Always On Display" toggle. */
    fun hasSystemAmbientSetting(context: Context): Boolean =
        try { Settings.Secure.getInt(context.contentResolver, "doze_always_on") >= 0 } catch (e: Settings.SettingNotFoundException) { false }

    fun isSystemAmbientEnabled(context: Context): Boolean =
        try { Settings.Secure.getInt(context.contentResolver, "doze_always_on") == 1 } catch (e: Settings.SettingNotFoundException) { false }

    /** Best-effort deep link to the system display settings where Always On / Ambient Display lives. */
    fun systemAmbientSettingsIntent(): Intent =
        Intent(Settings.ACTION_DISPLAY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    fun canOpenSettings(context: Context, intent: Intent): Boolean =
        intent.resolveActivity(context.packageManager) != null
}

package com.daksh.vision.aod

/**
 * Pure, side-effect-free evaluation of conditions, rules and modes against an [AodContext].
 * No Android dependency, so this is fully unit-testable without an emulator.
 */
object AodEngine {

    /**
     * [schedule] is the one configured in Scheduled mode - shared with Custom Rules so a
     * SCHEDULE_ACTIVE condition means exactly what it says: the current time actually falls
     * inside that schedule's window (and it's turned on), not merely that the schedule exists.
     */
    fun evaluateCondition(condition: Condition, ctx: AodContext, schedule: Schedule): Boolean = when (condition.type) {
        ConditionType.CHARGING -> ctx.charging == condition.boolValue
        ConditionType.BATTERY_ABOVE -> (ctx.batteryPercent ?: -1) > condition.intValue
        ConditionType.BATTERY_BELOW -> (ctx.batteryPercent ?: 101) < condition.intValue
        ConditionType.TIME_BETWEEN -> inRange(ctx.minutesOfDay, condition.timeStart.minutesOfDay, condition.timeEnd.minutesOfDay)
        ConditionType.SCHEDULE_ACTIVE -> schedule.isActiveAt(ctx.minutesOfDay, ctx.weekday, ctx.previousWeekday)
    }

    private fun inRange(now: Int, start: Int, end: Int): Boolean =
        if (start == end) true else if (start < end) now in start until end else now >= start || now < end

    fun evaluateRule(rule: CustomRule, ctx: AodContext, schedule: Schedule): RuleResult {
        val results = rule.conditions.map { ConditionResult(it, evaluateCondition(it, ctx, schedule)) }
        val satisfied = if (!rule.enabled) false else when (rule.logic) {
            Logic.AND -> results.all { it.satisfied }
            Logic.OR -> results.any { it.satisfied }
        }
        return RuleResult(rule, results, satisfied)
    }

    fun evaluateRules(rules: List<CustomRule>, ctx: AodContext, schedule: Schedule): List<RuleResult> =
        rules.map { evaluateRule(it, ctx, schedule) }

    /**
     * Whether VISION's configured behaviour should currently be active, for all non-rule modes.
     * Rule-based conflict resolution (CUSTOM_RULES) is: active if ANY enabled rule is satisfied —
     * i.e. rules combine with OR across each other, while each rule's own conditions use its chosen AND/OR.
     */
    fun isActive(state: AodState, ctx: AodContext): Boolean = when (state.mode) {
        AodMode.OFF -> false
        AodMode.ALWAYS_ON -> true
        AodMode.CHARGING_ONLY -> ctx.charging
        AodMode.SCHEDULED -> state.schedule.isActiveAt(ctx.minutesOfDay, ctx.weekday, ctx.previousWeekday)
        AodMode.BATTERY_THRESHOLD -> ctx.batteryPercent?.let { it >= state.batteryThreshold } ?: false
        AodMode.CUSTOM_RULES -> evaluateRules(state.rules, ctx, state.schedule).any { it.satisfied }
    }
}

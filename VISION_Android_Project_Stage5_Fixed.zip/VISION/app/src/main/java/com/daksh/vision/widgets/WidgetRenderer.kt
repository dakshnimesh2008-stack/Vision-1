package com.daksh.vision.widgets

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.BatteryManager
import android.text.format.DateFormat
import android.widget.RemoteViews
import com.daksh.vision.MainActivity
import com.daksh.vision.R
import com.daksh.vision.clock.FormatChoice
import com.daksh.vision.util.TimeFormatter
import java.time.LocalDateTime

/** Builds the real RemoteViews shown on the home screen for one widget instance. */
object WidgetRenderer {

    private fun layoutFor(size: WidgetSize): Int = when (size) {
        WidgetSize.SMALL -> R.layout.widget_small
        WidgetSize.MEDIUM -> R.layout.widget_medium
        WidgetSize.LARGE -> R.layout.widget_large
    }

    private fun resolve24(context: Context, format: FormatChoice): Boolean = when (format) {
        FormatChoice.H24 -> true
        FormatChoice.H12 -> false
        FormatChoice.APP -> DateFormat.is24HourFormat(context)
    }

    /** Reads the device's current battery percentage without a long-lived receiver. */
    private fun batteryPercent(context: Context): Int? {
        val filter = android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        val intent = context.registerReceiver(null, filter) ?: return null
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        if (level < 0 || scale <= 0) return null
        return (level * 100f / scale).toInt().coerceIn(0, 100)
    }

    fun build(context: Context, size: WidgetSize, config: WidgetConfig): RemoteViews {
        val views = RemoteViews(context.packageName, layoutFor(size))
        val now = LocalDateTime.now()
        val use24 = resolve24(context, config.format)

        // Background: a solid rounded shape, tinted at runtime (image is plain white).
        views.setInt(R.id.widget_bg, "setColorFilter", config.background)
        views.setInt(R.id.widget_bg, "setImageAlpha", 255)

        val weight = when (config.look) {
            WidgetLook.SIMPLE -> android.graphics.Typeface.NORMAL
            WidgetLook.BEAUTIFUL -> android.graphics.Typeface.NORMAL
            WidgetLook.ANIMATED -> android.graphics.Typeface.BOLD
        }
        views.setTextViewText(R.id.widget_time, TimeFormatter.time(now, use24, showSeconds = false))
        views.setTextColor(R.id.widget_time, config.main)
        views.setInt(R.id.widget_time, "setTypeface", weight)

        val ampm = TimeFormatter.amPm(now, use24)
        views.setTextViewText(R.id.widget_ampm, ampm)
        views.setTextColor(R.id.widget_ampm, config.accent)
        views.setViewVisibility(R.id.widget_ampm, if (ampm.isEmpty()) android.view.View.GONE else android.view.View.VISIBLE)

        // ANIMATED look gets a small accent dot standing in for the in-app design's motion.
        views.setViewVisibility(R.id.widget_dot, if (config.look == WidgetLook.ANIMATED) android.view.View.VISIBLE else android.view.View.GONE)
        views.setInt(R.id.widget_dot, "setColorFilter", config.accent)

        if (hasView(size, R.id.widget_date)) {
            views.setTextViewText(R.id.widget_date, TimeFormatter.dateShort(now))
            views.setTextColor(R.id.widget_date, config.accent)
            views.setViewVisibility(R.id.widget_date, if (config.showDate) android.view.View.VISIBLE else android.view.View.GONE)
        }
        if (hasView(size, R.id.widget_day)) {
            views.setTextViewText(R.id.widget_day, TimeFormatter.dayName(now).uppercase())
            views.setTextColor(R.id.widget_day, config.accent)
            views.setViewVisibility(R.id.widget_day, if (config.showDay) android.view.View.VISIBLE else android.view.View.GONE)
        }
        if (hasView(size, R.id.widget_battery)) {
            val pct = batteryPercent(context)
            views.setTextViewText(R.id.widget_battery, if (pct != null) "$pct%" else "")
            views.setTextColor(R.id.widget_battery, config.accent)
            views.setViewVisibility(
                R.id.widget_battery,
                if (config.showBattery && pct != null) android.view.View.VISIBLE else android.view.View.GONE,
            )
        }

        val openApp = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        views.setOnClickPendingIntent(R.id.widget_root, openApp)
        return views
    }

    /** Which optional views actually exist in each size's layout XML. */
    private fun hasView(size: WidgetSize, id: Int): Boolean = when (size) {
        WidgetSize.SMALL -> false
        WidgetSize.MEDIUM -> id == R.id.widget_date
        WidgetSize.LARGE -> id == R.id.widget_date || id == R.id.widget_day || id == R.id.widget_battery
    }
}

package com.daksh.vision.widgets

import android.text.format.DateFormat
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.daksh.vision.clock.FormatChoice
import com.daksh.vision.clock.rememberNow
import com.daksh.vision.util.TimeFormatter

/**
 * An in-app approximation of the real RemoteViews widget: same fields, same colours, same text.
 * This is a preview, not the home-screen widget itself - it has no continuous animation, matching
 * what RemoteViews can actually render.
 */
@Composable
fun WidgetPreview(size: WidgetSize, config: WidgetConfig, modifier: Modifier = Modifier) {
    val now = rememberNow()
    val use24 = when (config.format) {
        FormatChoice.H24 -> true
        FormatChoice.H12 -> false
        FormatChoice.APP -> DateFormat.is24HourFormat(LocalContext.current)
    }
    Box(
        modifier.clip(RoundedCornerShape(18.dp)).background(Color(config.background)).padding(14.dp),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
            if (config.look == WidgetLook.ANIMATED) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(Color(config.accent)))
            }
            Row2 {
                Text(
                    TimeFormatter.time(now, use24, showSeconds = false),
                    color = Color(config.main),
                    fontWeight = if (config.look == WidgetLook.ANIMATED) FontWeight.Bold else FontWeight.Normal,
                    style = MaterialTheme.typography.headlineMedium,
                )
                val ap = TimeFormatter.amPm(now, use24)
                if (ap.isNotEmpty()) Text(" $ap", color = Color(config.accent), style = MaterialTheme.typography.bodyMedium)
            }
            if (size != WidgetSize.SMALL && config.showDate)
                Text(TimeFormatter.dateShort(now), color = Color(config.accent), style = MaterialTheme.typography.bodyMedium)
            if (size == WidgetSize.LARGE && config.showDay)
                Text(TimeFormatter.dayName(now).uppercase(), color = Color(config.accent), style = MaterialTheme.typography.labelLarge)
            if (size == WidgetSize.LARGE && config.showBattery)
                Text("Battery", color = Color(config.accent), style = MaterialTheme.typography.labelLarge)
        }
    }
}

@Composable
private fun Row2(content: @Composable androidx.compose.foundation.layout.RowScope.() -> Unit) =
    androidx.compose.foundation.layout.Row(verticalAlignment = Alignment.Bottom, content = content)

package com.daksh.vision.clock

enum class ClockCategory(val label: String) { SIMPLE("Simple"), ANIMATED("Animated"), BEAUTIFUL("Beautiful") }
enum class Renderer { DIGITAL, ANALOG, RING, ORBIT }
enum class Decor { NONE, GRADIENT, GLASS, GLOW, ANIM_GRADIENT, PULSE }
enum class AnalogVariant { MINIMAL, CLASSIC, ELEGANT, NUMERALS }
enum class Family { SANS, SERIF, MONO }

/** Local font styles only (no downloads). [weight] null = use the clock design's own weight. */
enum class ClockFont(val label: String, val family: Family, val weight: Int?) {
    SANS("Sans", Family.SANS, null),
    SERIF("Serif", Family.SERIF, null),
    MONO("Mono", Family.MONO, null),
    LIGHT("Light", Family.SANS, 200),
    BOLD("Bold", Family.SANS, 800),
}

enum class FormatChoice(val label: String) { APP("App setting"), H12("12-hour"), H24("24-hour") }

/** Controls a clock can expose in the customization screen. */
enum class Option { PRESENTATION, MAIN, ACCENT, BACKGROUND, TEXT, FONT, FORMAT, DATE, SECONDS, DAY, BATTERY }

data class ClockStyle(
    val id: String,
    val name: String,
    val category: ClockCategory,
    val renderer: Renderer,
    val defaults: ClockConfig,
    val weight: Int = 300,
    val sizeScale: Float = 1f,
    val stacked: Boolean = false,
    val decor: Decor = Decor.NONE,
    val analogVariant: AnalogVariant = AnalogVariant.MINIMAL,
    /** Uses sub-second animation (smooth hands, pulse, moving gradient). */
    val smooth: Boolean = false,
    val animatedDigits: Boolean = false,
    /** Can be switched between digital and analog by the user. */
    val toggle: Boolean = false,
) {
    fun effectiveRenderer(cfg: ClockConfig): Renderer =
        if (toggle) (if (cfg.analog) Renderer.ANALOG else Renderer.DIGITAL) else renderer

    /** Only the controls that actually affect this clock in its current presentation. */
    fun options(cfg: ClockConfig): Set<Option> {
        val o = mutableSetOf(Option.MAIN, Option.ACCENT, Option.BACKGROUND, Option.TEXT,
            Option.DATE, Option.DAY, Option.BATTERY, Option.SECONDS)
        if (effectiveRenderer(cfg) != Renderer.ANALOG) { o += Option.FONT; o += Option.FORMAT }
        if (toggle) o += Option.PRESENTATION
        return o
    }
}

/** Colours are stored as ARGB ints so this class has no UI dependency. */
data class ClockConfig(
    val main: Int,
    val accent: Int,
    val background: Int,
    val text: Int,
    val font: ClockFont = ClockFont.SANS,
    val format: FormatChoice = FormatChoice.APP,
    val showDate: Boolean = true,
    val showSeconds: Boolean = false,
    val showDay: Boolean = false,
    val showBattery: Boolean = false,
    val analog: Boolean = false,
) {
    fun resolve24(appUse24h: Boolean): Boolean = when (format) {
        FormatChoice.APP -> appUse24h
        FormatChoice.H12 -> false
        FormatChoice.H24 -> true
    }

    fun encode(): String = listOf(
        main, accent, background, text, font.name, format.name,
        showDate, showSeconds, showDay, showBattery, analog,
    ).joinToString("|")

    companion object {
        /** Never throws: any corrupt or outdated value falls back to [fallback]. */
        fun decode(raw: String?, fallback: ClockConfig): ClockConfig {
            if (raw.isNullOrBlank()) return fallback
            val p = raw.split("|")
            if (p.size != 11) return fallback
            return try {
                ClockConfig(
                    main = p[0].toInt(), accent = p[1].toInt(), background = p[2].toInt(), text = p[3].toInt(),
                    font = ClockFont.values().firstOrNull { it.name == p[4] } ?: return fallback,
                    format = FormatChoice.values().firstOrNull { it.name == p[5] } ?: return fallback,
                    showDate = p[6].toStrictBool(), showSeconds = p[7].toStrictBool(),
                    showDay = p[8].toStrictBool(), showBattery = p[9].toStrictBool(), analog = p[10].toStrictBool(),
                )
            } catch (e: IllegalArgumentException) {
                fallback
            }
        }

        private fun String.toStrictBool(): Boolean = when (this) {
            "true" -> true
            "false" -> false
            else -> throw IllegalArgumentException("bad boolean")
        }
    }
}

data class ClockState(val selectedId: String, val configs: Map<String, ClockConfig>) {
    fun configFor(style: ClockStyle): ClockConfig = configs[style.id] ?: style.defaults
    val selected: ClockStyle get() = ClockLibrary.byId(selectedId) ?: ClockLibrary.default
}

package com.daksh.vision.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.daksh.vision.MainViewModel
import com.daksh.vision.aod.AodContext
import com.daksh.vision.aod.AodEngine
import com.daksh.vision.aod.Condition
import com.daksh.vision.aod.ConditionType
import com.daksh.vision.aod.CustomRule
import com.daksh.vision.aod.Logic
import com.daksh.vision.aod.Schedule
import com.daksh.vision.data.AodRepository
import com.daksh.vision.data.AppSettings

@Composable
fun CustomRulesHeader(vm: MainViewModel) {
    var creating by rememberSaveable { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth()) {
        Button(onClick = { creating = true }) {
            Icon(Icons.Outlined.Add, contentDescription = null, modifier = Modifier.padding(end = 6.dp))
            Text("New rule")
        }
    }
    if (creating) {
        RuleEditorDialog(
            initial = CustomRule(id = AodRepository.newRuleId(), name = "New rule"),
            onDismiss = { creating = false },
            onSave = { rule -> vm.addAodRule(rule); creating = false },
        )
    }
}

@Composable
fun RuleCard(rule: CustomRule, ctx: AodContext, schedule: Schedule, settings: AppSettings, vm: MainViewModel) {
    var editing by rememberSaveable(rule.id) { mutableStateOf(false) }
    val result = remember(rule, ctx, schedule) { AodEngine.evaluateRule(rule, ctx, schedule) }
    val use24 = resolveUse24h(settings)

    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(rule.name, style = MaterialTheme.typography.titleMedium)
                    Text(
                        if (!rule.enabled) "Disabled" else if (result.satisfied) "Satisfied now" else "Not satisfied now",
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (rule.enabled && result.satisfied) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Switch(checked = rule.enabled, onCheckedChange = { vm.setAodRuleEnabled(rule.id, it) })
            }
            result.conditionResults.forEachIndexed { i, cr ->
                if (i > 0) Text(rule.logic.name, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                Text(
                    "• ${describe(cr.condition, use24)} — ${if (cr.satisfied) "met" else "not met"}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (cr.satisfied) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = { editing = true }) { Text("Edit") }
                TextButton(onClick = { vm.deleteAodRule(rule.id) }) { Text("Delete") }
            }
        }
    }
    if (editing) {
        RuleEditorDialog(initial = rule, onDismiss = { editing = false }, onSave = { vm.updateAodRule(it); editing = false })
    }
}

private fun describe(c: Condition, use24: Boolean): String = when (c.type) {
    ConditionType.CHARGING -> "Charging = ${c.boolValue}"
    ConditionType.BATTERY_ABOVE -> "Battery level is above ${c.intValue}%"
    ConditionType.BATTERY_BELOW -> "Battery level is below ${c.intValue}%"
    ConditionType.TIME_BETWEEN -> "Current time is between ${c.timeStart.format(use24)} and ${c.timeEnd.format(use24)}"
    ConditionType.SCHEDULE_ACTIVE -> "Current time is inside your Scheduled-mode window"
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun RuleEditorDialog(initial: CustomRule, onDismiss: () -> Unit, onSave: (CustomRule) -> Unit) {
    var name by rememberSaveable(initial.id) { mutableStateOf(initial.name) }
    var logic by rememberSaveable(initial.id) { mutableStateOf(initial.logic) }
    var conditions by remember(initial.id) { mutableStateOf(initial.conditions) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial.name == "New rule" && conditions.size <= 1) "New rule" else "Edit rule") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Rule name") })
                Text("Combine conditions with", style = MaterialTheme.typography.bodyMedium)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Logic.values().forEach { l -> FilterChip(logic == l, { logic = l }, { Text(l.name) }) }
                }
                conditions.forEachIndexed { index, cond ->
                    ConditionEditor(
                        cond,
                        onReplace = { updated -> conditions = conditions.toMutableList().also { it[index] = updated } },
                        onRemove = if (conditions.size > 1) {
                            { conditions = conditions.toMutableList().also { it.removeAt(index) } }
                        } else null,
                    )
                }
                OutlinedButton(onClick = { conditions = conditions + Condition() }) { Text("Add condition") }
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onSave(CustomRule(initial.id, name.ifBlank { "Untitled rule" }, logic, conditions, initial.enabled)) },
            ) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ConditionEditor(
    cond: Condition,
    onReplace: (Condition) -> Unit,
    onRemove: (() -> Unit)?,
) {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Condition", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            if (onRemove != null) IconButton(onClick = onRemove) { Icon(Icons.Outlined.Delete, contentDescription = "Remove condition") }
        }
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            ConditionType.values().forEach { t ->
                FilterChip(cond.type == t, { onReplace(cond.copy(type = t)) }, { Text(t.label) })
            }
        }
        when (cond.type) {
            ConditionType.CHARGING -> FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(cond.boolValue, { onReplace(cond.copy(boolValue = true)) }, { Text("True") })
                FilterChip(!cond.boolValue, { onReplace(cond.copy(boolValue = false)) }, { Text("False") })
            }
            ConditionType.BATTERY_ABOVE, ConditionType.BATTERY_BELOW -> OutlinedTextField(
                value = cond.intValue.toString(),
                onValueChange = { v -> v.toIntOrNull()?.let { if (it in 0..100) onReplace(cond.copy(intValue = it)) } },
                label = { Text("Percent") },
                modifier = Modifier.fillMaxWidth(),
            )
            ConditionType.TIME_BETWEEN -> Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                TimePickerField("From", cond.timeStart, use24 = true) { onReplace(cond.copy(timeStart = it)) }
                TimePickerField("To", cond.timeEnd, use24 = true) { onReplace(cond.copy(timeEnd = it)) }
            }
            ConditionType.SCHEDULE_ACTIVE -> Text(
                "Satisfied whenever the current time falls inside the start/end window you set for " +
                    "Scheduled mode, and that schedule is turned on - not merely whenever it exists.",
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

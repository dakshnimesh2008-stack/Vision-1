package com.daksh.vision.aod

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AodEngineTest {
    private fun ctx(charging: Boolean = false, battery: Int? = 50, minutes: Int = 12 * 60, day: Weekday = Weekday.MON, prev: Weekday = Weekday.SUN) =
        AodContext(charging, battery, minutes, day, prev)

    private val noSchedule = Schedule() // used wherever a test doesn't care about SCHEDULE_ACTIVE

    @Test fun offIsNeverActive() = assertFalse(AodEngine.isActive(AodState(mode = AodMode.OFF), ctx(charging = true)))

    @Test fun alwaysOnIsAlwaysActive() = assertTrue(AodEngine.isActive(AodState(mode = AodMode.ALWAYS_ON), ctx()))

    @Test fun chargingOnlyFollowsRealChargingState() {
        val state = AodState(mode = AodMode.CHARGING_ONLY)
        assertTrue(AodEngine.isActive(state, ctx(charging = true)))
        assertFalse(AodEngine.isActive(state, ctx(charging = false)))
    }

    @Test fun batteryThresholdUsesRealPercent() {
        val state = AodState(mode = AodMode.BATTERY_THRESHOLD, batteryThreshold = 30)
        assertTrue(AodEngine.isActive(state, ctx(battery = 30)))
        assertTrue(AodEngine.isActive(state, ctx(battery = 80)))
        assertFalse(AodEngine.isActive(state, ctx(battery = 29)))
        assertFalse(AodEngine.isActive(state, ctx(battery = null))) // unknown battery never satisfies a floor
    }

    @Test fun scheduledFollowsScheduleWindow() {
        val schedule = Schedule(TimeOfDay(9, 0), TimeOfDay(17, 0), setOf(Weekday.MON))
        val state = AodState(mode = AodMode.SCHEDULED, schedule = schedule)
        assertTrue(AodEngine.isActive(state, ctx(minutes = 12 * 60, day = Weekday.MON, prev = Weekday.SUN)))
        assertFalse(AodEngine.isActive(state, ctx(minutes = 20 * 60, day = Weekday.MON, prev = Weekday.SUN)))
    }

    @Test fun andRuleRequiresAllConditions() {
        val rule = CustomRule(
            "r1", "Charging and high battery", Logic.AND,
            listOf(Condition(ConditionType.CHARGING, boolValue = true), Condition(ConditionType.BATTERY_ABOVE, intValue = 50)),
        )
        val result = AodEngine.evaluateRule(rule, ctx(charging = true, battery = 60), noSchedule)
        assertTrue(result.satisfied)
        assertTrue(result.conditionResults.all { it.satisfied })

        val partial = AodEngine.evaluateRule(rule, ctx(charging = true, battery = 10), noSchedule)
        assertFalse(partial.satisfied)
        assertEquals(1, partial.conditionResults.count { !it.satisfied })
    }

    @Test fun orRuleRequiresAnyCondition() {
        val rule = CustomRule(
            "r2", "Charging or late night", Logic.OR,
            listOf(
                Condition(ConditionType.CHARGING, boolValue = true),
                Condition(ConditionType.TIME_BETWEEN, timeStart = TimeOfDay(22, 0), timeEnd = TimeOfDay(6, 0)),
            ),
        )
        assertTrue(AodEngine.evaluateRule(rule, ctx(charging = true, minutes = 12 * 60), noSchedule).satisfied)
        assertTrue(AodEngine.evaluateRule(rule, ctx(charging = false, minutes = 23 * 60), noSchedule).satisfied)
        assertFalse(AodEngine.evaluateRule(rule, ctx(charging = false, minutes = 12 * 60), noSchedule).satisfied)
    }

    @Test fun disabledRuleIsNeverSatisfiedEvenIfConditionsMatch() {
        val rule = CustomRule("r3", "Disabled", Logic.AND, listOf(Condition(ConditionType.CHARGING, boolValue = true)), enabled = false)
        assertFalse(AodEngine.evaluateRule(rule, ctx(charging = true), noSchedule).satisfied)
    }

    @Test fun customRulesModeActiveIfAnyEnabledRuleSatisfied() {
        val r1 = CustomRule("a", "A", Logic.AND, listOf(Condition(ConditionType.CHARGING, boolValue = true)), enabled = true)
        val r2 = CustomRule("b", "B", Logic.AND, listOf(Condition(ConditionType.BATTERY_BELOW, intValue = 10)), enabled = true)
        val state = AodState(mode = AodMode.CUSTOM_RULES, rules = listOf(r1, r2))
        assertTrue(AodEngine.isActive(state, ctx(charging = true, battery = 90))) // r1 satisfied
        assertFalse(AodEngine.isActive(state, ctx(charging = false, battery = 90))) // neither satisfied
    }

    @Test fun noRulesMeansCustomRulesModeIsInactive() {
        assertFalse(AodEngine.isActive(AodState(mode = AodMode.CUSTOM_RULES, rules = emptyList()), ctx(charging = true)))
    }

    // --- Regression coverage: SCHEDULE_ACTIVE must check the real time window, not a stored flag ---

    @Test fun scheduleActiveConditionChecksRealWindowNotAStoredFlag() {
        val schedule = Schedule(TimeOfDay(9, 0), TimeOfDay(17, 0), setOf(Weekday.MON), enabled = true)
        val condition = Condition(ConditionType.SCHEDULE_ACTIVE, boolValue = false) // boolValue deliberately wrong/unused
        // Inside the window: must be satisfied even though boolValue above is false.
        assertTrue(AodEngine.evaluateCondition(condition, ctx(minutes = 12 * 60, day = Weekday.MON, prev = Weekday.SUN), schedule))
        // Outside the window: must NOT be satisfied even if boolValue were true.
        val insideBool = condition.copy(boolValue = true)
        assertFalse(AodEngine.evaluateCondition(insideBool, ctx(minutes = 20 * 60, day = Weekday.MON, prev = Weekday.SUN), schedule))
    }

    @Test fun scheduleActiveConditionRespectsDisabledSchedule() {
        val disabled = Schedule(TimeOfDay(0, 0), TimeOfDay(0, 0), Weekday.values().toSet(), enabled = false)
        val condition = Condition(ConditionType.SCHEDULE_ACTIVE)
        assertFalse(AodEngine.evaluateCondition(condition, ctx(minutes = 12 * 60), disabled))
    }

    @Test fun customRuleWithScheduleActiveConditionUsesSharedSchedule() {
        val schedule = Schedule(TimeOfDay(22, 0), TimeOfDay(6, 0), setOf(Weekday.FRI)) // overnight window
        val rule = CustomRule("sr", "Night rule", Logic.AND, listOf(Condition(ConditionType.SCHEDULE_ACTIVE)))
        // 23:00 Friday is inside the overnight window.
        assertTrue(AodEngine.evaluateRule(rule, ctx(minutes = 23 * 60, day = Weekday.FRI, prev = Weekday.THU), schedule).satisfied)
        // Noon Friday is outside it.
        assertFalse(AodEngine.evaluateRule(rule, ctx(minutes = 12 * 60, day = Weekday.FRI, prev = Weekday.THU), schedule).satisfied)
    }
}
